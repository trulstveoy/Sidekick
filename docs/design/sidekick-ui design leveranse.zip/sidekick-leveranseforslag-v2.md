# Leveranseforslag v2: Sidekick GUI-refresh

**Fra:** Design- og interaksjonskonsulent  
**Til:** Sidekick-produktteam  
**Status:** Revidert forslag – til godkjenning  
**Dato:** 11. mai 2026  
**Basert på:** Tilbakemelding mottatt 11. mai 2026

---

## Endringer fra v1

Følgende er innarbeidet i dette reviderte forslaget:

- Sluttpakken inkluderer visuelt løste referanseskjermer for de viktigste tilstandene
- "Tredelt hierarki" er fjernet som begrep – IA behandles som informasjonsstruktur, ikke layoutkrav
- Arbeidsmodi er justert til: **Forstå**, **Strukturere**, **Produsere/Assistere**
- Tilgjengelighet, tomme tilstander, feil, advarsler og suksess er ikke lenger en avsluttende fase – de inngår som akseptansekriterier i hver relevant oppgave
- Oppgavespesifikasjoner er avgrenset til problem, mål, scope, designkrav og akseptansekriterier – ingen implementasjonsplan
- Figma er ikke påkrevd. All endelig leveranse er verktøyuavhengig og repo-vennlig
- Leveranseformater er presisert (se nedenfor)
- Plattform: Windows primært, Linux sekundært, macOS utenfor scope
- Vindusstørrelser: 1280 × 820 som referanse, 1040 × 720 som definert minimumsopplevelse
- Produktspråk: norsk primært
- Mørk modus: ikke krav nå, men designsystemet skal ikke hindre det senere

---

## Produktforståelse

Sidekick er et lokalt, fillbasert skrivebordsverktøy for kunnskapsarbeid. Brukeren holder prosjektmateriale i lokale mapper og trenger hjelp til å forstå, holde orden på og bruke dette materialet – uten å miste kontroll over filene sine.

AI-funksjonalitet er et hjelpemiddel i en definert, kontrollert kontekst. Tillitsmodellen er lokal og eksplisitt. Designets viktigste ansvar er at brukeren alltid vet hva som skjer med filene sine og hvilken mappe operasjoner gjelder.

Den viktigste brukerfrustrasjon med nåværende UI er: for mye støy og for lite prioritering. For mange filer og detaljer å skanne på én gang. Refreshen skal gi bedre prosjektforståelse, tydeligere struktur og roligere handlingsflater.

---

## Arbeidsmodi

Applikasjonens tre primære arbeidsmodi er:

**Forstå** – Brukeren orienterer seg i prosjektet. Hva finnes? Hva er nylig endret? Hva ser ufullstendig ut? Denne modusen er alltid lesebeskyttet.

**Strukturere** – Brukeren gjennomfører konkrete, eksplisitte skriveoperasjoner: importere en transkripsjon, opprette en ny prosjektmappe. Hver slik handling er avgrenset, forutsigbar og bekrefter seg selv.

**Produsere/Assistere** – Brukeren ber Sidekick generere noe: en kontekstpakke for AI-assistanse, eller en kontrollert Codex-operasjon. Disse handlingene har tydelig scope og krever eksplisitt bekreftelse eller forhåndsvisning.

Disse modiene er ikke navigasjonselementer – de er en mental modell som guider prioritering av informasjon og handlinger i designet.

---

## Anbefalte designartefakter

### 1. UX- og produktrammeverk
**Format:** Markdown  
**Fidelitet:** Konseptuell – prosa og tabellariske oversikter  
**Innhold:**
- Arbeidsmodi med beskrivelse av primære, sekundære og sjeldne handlinger
- Informasjonsprioritering per modus
- Prinsipper for lokal tillitsmodell i interaksjon
- Designprinsipper for tetthet, leseretning og statussynlighet

---

### 2. Informasjonsarkitektur
**Format:** draw.io-diagram (.drawio eller eksportert SVG/PNG) + Markdown-forklaring  
**Fidelitet:** Strukturdiagram – ikke visuell design, ikke layoutkrav  
**Innhold:**
- Navigasjons- og visningsmodell
- Inngangsflyt: ingen aktiv kontekst → velge mappe → opprette mappe
- Struktur for prosjektforståelse: oversikt → signal- og artefaktinformasjon → fildetalj
- Plassering av import-, genererings- og assistentoperasjoner
- Hvor feil, varsler og aktivitetstilstander fremkommer

---

### 3. Arbeidsflyt-wireflows
**Format:** Annoterte SVG-filer (eller HTML/CSS) + Markdown-forklaring  
**Fidelitet:** Gråtone wireframes med tilstandsbeskrivelser og annotasjoner  
**Dekker:**

| Arbeidsflyt | Prioritet |
|---|---|
| Start uten aktiv prosjektkontekst (tom tilstand) | Høy |
| Velge eksisterende prosjektmappe | Høy |
| Opprette ny prosjektmappe | Høy |
| Forstå skannet prosjekt (oversikt) | Høy |
| Utforske mappestrukturer og artefaktinformasjon | Høy |
| Importere transkripsjon | Høy |
| Forhåndsvisning av kontekstpakke | Høy |
| Generere kontekstpakke | Høy |
| Sjekke Codex-tilgjengelighet og innloggingsstatus | Middels |
| Kjøre skrivebeskyttet Codex-operasjon | Middels |
| Kjøre redigeringsmodus Codex-operasjon | Middels |
| Avbryte Codex-operasjon | Middels |
| Forstå suksess-, advarsel- og feiltilstander | Høy |

Alle wireflows inkluderer eksplisitte tilstandsbeskrivelser: tom, laster, suksess, feil, advarsel, kant-case.

---

### 4. Visuelt løste referanseskjermer
**Format:** SVG eller PNG (eventuelt HTML/CSS-prototype)  
**Fidelitet:** Høy – visuelt løst med faktisk fargepalett, typografi, tetthet og komponentstil  
**Formål:** Gjøre det mulig å vurdere typografi, fargbruk, tetthet, komponenter og statusbehandling i praksis  
**Dekker minimum:**
- Prosjektoversikt – skannet prosjekt med mappe- og artefaktinformasjon
- Tom tilstand – ingen aktiv prosjektkontekst
- Transkripsjonimport – bekreftelsestilstand
- Kontekstpakke – forhåndsvisnings- og resultattilstand
- Codex-kjøring – strømmende output og fullføring
- Feil- og advarselstilstand (generisk)

Disse skjermbildene er referanser for implementasjonen, ikke uttømmende design for alle tilstander.

---

### 5. Skjerm- og tilstandsinventar
**Format:** Markdown  
**Innhold:** Komplett liste over skjermbilder, paneler, dialoger og tilstander.  
For hver tilstand beskrives: formål, primær brukeroppgave, nøkkelinformasjon, primære handlinger, sekundære handlinger, tom tilstand, ladetilstand, feiltilstand, suksesstistand, kant-caser.

---

### 6. Visuelt designsystem
**Format:** Markdown-spesifikasjon + JSON for design tokens  
**Innhold:**
- Fargepalett med semantiske tokens (primær, nøytral, advarsel, feil, suksess, info)
- Token-verdier som ikke hindrer mørk modus later
- Typografi (font, skala, vekt, linjehøyde)
- Avstandsskala
- Tetthetsregler (kompakt/standard) – referansestørrelse 1280 × 820, minimum 1040 × 720
- Ikonsstil og anbefalinger (kompatibel med Windows/Linux native kontekst)
- Kantlinjer og skillelinjer
- Elevasjon (minimal, sober)
- Fokustilstander
- Valgstilstander
- Deaktivert tilstand
- Advarsel-, feil-, suksess- og fremgangsbehandling
- Bevegelse (begrenset og formålsdrevet)

---

### 7. Komponentveiledning
**Format:** Annoterte SVG/PNG + Markdown-atferdsbeskrivelser  
**Komponenter:**
- Prosjektselektor og prosjektinngangsmønster
- Mappestruktur- og artefaktvisning
- Metadataoppsummering og signalbehandling
- Handlingsflater (primær, sekundær, destruktiv)
- Forhåndsvisning/bekreftelsesmønster for skriveoperasjoner
- Advarsel- og feilvisning
- Fremdrifts- og strømmende output-visning
- Filimportmønster
- Kontekstpakke-resultatvisning
- Kontrollert assistent-kjøremønster
- Innstillinger/statuspanel for Codex

---

### 8. Innhold og terminologi
**Format:** Markdown  
**Innhold:**
- Norsk produktspråk for alle begreper (med engelsk der det gir mening, f.eks. "Codex")
- Handlingsetiketter
- Statusspråk
- Feilspråk (presist, ikke teknisk)
- Advarselsspråk
- Bekreftelsesspråk
- Terminologi for AI-assisterte operasjoner
- Terminologi for kontekstpakkegenerering
- Terminologi for transkripsjonsimport

---

### 9. Implementasjons-handoff med oppgavespesifikasjoner
**Format:** Markdown (én fil per oppgave)  
**Innhold:**
- Annoterte referanseskjermer
- Design tokens (JSON)
- Komponentspesifikasjoner
- Interaksjonsnotater
- Oppgavespesifikasjoner i det definerte formatet (problem, mål, scope, non-goals, designkrav, akseptansekriterier, avhengigheter, åpne spørsmål)
- Design QA-sjekkliste

**Presisering:** Oppgavespesifikasjonene beskriver problem, mål, scope, designkrav og observerbare akseptansekriterier. De inneholder ikke implementasjonsplan, arkitekturvalg, filstruktur, teststrategi eller tekniske valg – det defineres av dere.

**Presisering om tilgjengelighet og tilstander:** Tilgjengelighet, tastaturbruk, tomme tilstander, feil, advarsler og suksess inngår som akseptansekriterier i hver relevant oppgave – de er ikke en separat fase.

---

## Leveranseformater – sammendrag

| Artefakt | Format |
|---|---|
| UX-rammeverk | Markdown |
| Informasjonsarkitektur | draw.io (.drawio) + SVG/PNG-eksport + Markdown |
| Wireflows | Annotert SVG + Markdown |
| Visuelt løste referanseskjermer | SVG eller PNG (ev. HTML/CSS-prototype) |
| Tilstandsinventar | Markdown |
| Designsystem | Markdown + JSON (design tokens) |
| Komponentveiledning | SVG/PNG + Markdown |
| Terminologi | Markdown |
| Handoff + oppgavespesifikasjoner | Markdown (én fil per oppgave) |

All leveranse er repo-vennlig og verktøyuavhengig. Figma brukes ikke som leveranseverktøy.

---

## Sekvens og gjennomgangspunkter

```
Fase 1 – Fundament
  ├── UX- og produktrammeverk (arbeidsmodi, prinsipper)
  └── Informasjonsarkitektur (strukturdiagram)

  → Gjennomgang: Er arbeidsmodi, informasjonsstruktur og prioritering riktig?

Fase 2 – Arbeidsflyt og tilstander
  ├── Wireflows (alle høyprioriterte arbeidsflyter)
  └── Skjerm- og tilstandsinventar

  → Gjennomgang: Er tilstander og flyter fullstendige og korrekte?

Fase 3 – Visuelt system
  ├── Designsystem (farger, typografi, spacing, tokens)
  ├── Visuelt løste referanseskjermer (nøkkelskjermer)
  └── Komponentveiledning

  → Gjennomgang: Er visuelt nivå, tetthet og statusbehandling riktig?

Fase 4 – Innhold og handoff
  ├── Terminologi og produktspråk
  └── Implementasjons-handoff med oppgavespesifikasjoner

  → Endelig gjennomgang og godkjenning
```

---

## Foreslåtte implementasjonsoppgaver

Basert på briefen og presiseringene foreslår jeg disse oppgavene for implementasjonen:

1. **Designsystem og delte komponenter** – tokens, typografi, fokus, tilstander
2. **Prosjektinngangserfaringen** – åpne og opprette prosjekt, tom tilstand
3. **Prosjektoversikt og forståelse** – skannet prosjektvisning, signaler, statistikk
4. **Mappestruktur og artefaktvisning** – hierarki, metadata, navigasjon
5. **Transkripsjonimport** – flyt, nummerering, bekreftelse
6. **Kontekstpakke** – forhåndsvisning, generering, resultat
7. **Codex-assistentflyt** – tilgjengelighet, kjøring, strøm, avbryt, fullføring
8. **Globale tilstander** – feil, varsler, fremgang, tomme flater, aktivitetsfeedback

Tilgjengelighet, tastaturnavigasjon og tilstandsbehandling inngår i akseptansekriteriene for hver oppgave – de er ikke en separat oppgave.

---

## Hva jeg trenger nå

### Nødvendig for oppstart
- [ ] **Skjermbilder eller tilgang til demo** – for å kartlegge eksisterende kapabiliteter og konkrete problemer, ikke som layoutmal
- [ ] **Godkjenning av dette forslaget** (ev. med ytterligere presiseringer)

### Nyttig å ha tidlig
- [ ] Finnes det et eksisterende ikonsett i bruk i dag?
- [ ] Er det spesifikke Windows-native mønstre dere ønsker å følge (f.eks. Window Chrome, kontekstmenyer)?
- [ ] Er det enkeltskjermer i nåværende app som fungerer godt og bør bevares som referanse?

---

## Hva som er utenfor scope

- Implementasjon av kode
- Ingeniørplaner og arkitekturvalg
- Figma som leveranseverktøy
- Redesign som sky-, chat- eller terminalprodukt
- Mobilversjon
- macOS-tilpasning
- Mørk modus (ikke krav nå)
- Markedsføring og onboarding

---

*Revidert forslag klar for godkjenning. Jeg starter detaljert designarbeid så snart dette er bekreftet og vi har mottatt skjermbilder/demo.*
