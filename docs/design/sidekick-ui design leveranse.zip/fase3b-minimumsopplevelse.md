# Sidekick – Minimumsopplevelse ved 1040×720
Fase 3b · 11. mai 2026

Referansestørrelse: **1280×820**
Minimumsstørrelse: **1040×720**
Breddereduksjon: −240px (−18,75 %)
Høydereduksjon: −100px (−12,2 %)

---

## Prinsipp

Minimumsvinduet skal gi tilgang til alle primærfunksjoner. Ingenting viktig forsvinner – det komprimeres, kollapser eller skjules gradvis. Sekundær informasjon (ekstra kolonner, hjelpetekst, utvidede statistikker) kan reduseres eller utelates.

Fokusrekkefølge og skjermleserrekkefølge skal ikke påvirkes av responsgveiledende justeringer.

---

## Komponent-for-komponent

### Topbar (44px høyde – uendret)

| Element | Ved 1280px | Ved 1040px |
|---------|-----------|-----------|
| Logo | Synlig | Synlig |
| Prosjektnavn | Synlig med full sti | Kun prosjektnavn (sti forkortes med `…`) |
| Modus-knapper (Forstå / Strukturere / Assistere) | Synlige | Synlige |
| Modus-knapper: label | Full tekst | Full tekst (knappene er korte) |

Topbar er alltid full bredde og høyde. Ingen kollapsing.

---

### Stats-stripe (48px høyde – uendret høyde)

| Antall stats synlige | Ved 1280px | Ved 1040px |
|----------------------|-----------|-----------|
| Primære stats (alltid synlige) | 7 | 4 |
| Skjulte stats | 0 | 3 |

**De 4 som alltid er synlige:**
1. Antall filer totalt
2. Antall mapper
3. Siste skanning (dato)
4. Kontekstpakke-status (finnes / mangler)

**De 3 som skjules ved 1040px:**
5. Størrelse på disk
6. Antall transkripsjoner
7. Antall varsler

Skjulte stats vises ikke med overflow eller scrollbar – de fjernes helt fra layout. En liten «+3 til» (eller liknende) indikator er valgfri.

---

### Sidebar (280px → 240px)

| Egenskap | Ved 1280px | Ved 1040px |
|----------|-----------|-----------|
| Bredde | 280px | 240px |
| Innhold | Full | Full (tekst får litt trangere padding) |
| Skjules | Nei | Nei |
| Padding innad | 16px | 12px |

Sidebar skjules aldri ved minimumsbredde – den er nødvendig for navigasjon og kontekstuell informasjon. Ved ekstremt smal skjerm (under 1040px, som ikke støttes) ville den måtte collapses til ikoner.

---

### Mappelistekolonner

| Kolonne | Ved 1280px | Ved 1040px |
|---------|-----------|-----------|
| Mappenavn | Synlig, fleksibel bredde | Synlig, fleksibel bredde |
| Signal (varsel-ikon) | Synlig | Synlig |
| Filtyper | Synlig (pip-badges) | Synlig |
| Antall filer | Synlig | Synlig |
| Sist endret | Synlig | **Skjules** |

Kolonnen «Sist endret» er sekundær metadata og er den første som fjernes ved platsmangel.

---

### Handlingsbar (52px – uendret)

Handlingsbaren er alltid synlig og på full bredde. Ingen knapper fjernes ved minimumsvindu.

Ved svært trang visning (nær 1040px) kan knapp-tekst forkortes:
- «Generer kontekstpakke» → «Generer kontekstpakke» (beholdes, er den primære handlingen)
- «Importer transkripsjon» → «Importer transkripsjon» (beholdes)
- Sekundærknapper kan miste sin ikontekst og vise bare ikon

---

### Statuslinje (24px – uendret)

Alltid synlig. Tekst forkortes med ellipsis (`…`) hvis den er for lang.

---

### Panel-innhold (scrollbart)

Alt panel-innhold (mappestruktur, transkripsjonsliste, Codex-output, kontekstpakke-visning) er scrollbart vertikalt. Det er ingen minimumsgrense for panelinnholdets høyde – brukeren scroller om nødvendig.

**Ikke-scrollbart:** Topbar, stats-stripe, handlingsbar, statuslinje – disse er alltid i syne.

---

### Modaler og overlays

Modaler sentreres i vindusflaten og har en fast maksimal bredde på 480px. De tilpasses uten problemer ned til 1040px vindubredde.

---

## Handlinger som alltid er tilgjengelige

Uavhengig av vinduestørrelse (ned til 1040×720) skal disse alltid være klikkbare:

1. Velg ny prosjektmappe
2. Start skanning / skann på nytt
3. Generer kontekstpakke
4. Importer transkripsjon
5. Åpne Codex-assistent
6. Navigere mellom arbeidsmodi (Forstå / Strukturere / Assistere)
7. Tilbake-navigasjon i drill-down og flerstegs-flyter

---

## Ikke støttet under 1040×720

Vinduer smalere enn 1040px eller lavere enn 720px støttes ikke. Applikasjonen viser ingen feilmelding, men layout kan brytes. Electron-vinduet bør settes med `minWidth: 1040, minHeight: 720` for å forhindre at brukeren drar vinduet under minimum.

---

## Oppsummering

| Komponent | Minimumsstørrelse | Endring fra referanse |
|-----------|------------------|-----------------------|
| Topbar | 44px høyde, full bredde | Prosjektsti forkortes |
| Stats-stripe | 48px høyde, 4 stats | 3 stats skjules |
| Sidebar | 240px bredde | −40px fra 280px |
| Mappekolonner | 3 av 4 | «Sist endret» skjules |
| Handlingsbar | 52px høyde, full bredde | Uendret |
| Statuslinje | 24px høyde | Uendret (tekst forkortes) |
| Panel-innhold | Scrollbart | Uendret |
