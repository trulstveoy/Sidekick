# Sidekick – UX- og produktrammeverk

**Fase 1 · Leveranse 1 av 2**  
**Dato:** 11. mai 2026  
**Status:** Klar for gjennomgang

---

## Produktets kjerne

Sidekick er et skrivebordsverktøy for kunnskapsarbeidere som holder prosjektmaterialet sitt i lokale mapper. Kjerneoppgaven er å hjelpe brukeren forstå hva som finnes i en prosjektmappe, og gi kontrollerte muligheter til å strukturere og produsere fra det materialet.

**Kjernesetning:**  
*Sidekick gjør det enkelt å forstå en lokal prosjektmappe – og gir presise, eksplisitte handlinger for å importere, organisere og produsere fra det som finnes.*

AI-funksjonalitet er et hjelpemiddel i en avgrenset, kontrollert kontekst. Det er ikke produktets identitet. Den viktigste bruksverdien er prosjektforståelse og strukturert arbeid med filer – ikke chat eller generative oppgaver.

---

## Tre arbeidsmodi

Applikasjonen har tre mentale arbeidsmodi. De er ikke navigasjonselementer, men en modell som guider hva som er fremtredende, hva som er tilgjengelig og hva som krever bevisst handling.

---

### Forstå

Brukeren orienterer seg i prosjektet. Hva finnes? Hva er nylig endret? Hvilke mapper inneholder hva? Hva ser ufullstendig eller uklassifisert ut?

Forstå-modusen er alltid **lesebeskyttet**. Ingen handling i denne modusen endrer noe på disk.

**Primære aktiviteter:**
- Se prosjektsti og -navn
- Lese mappestruktur og hierarki
- Se artefakttyper og antall per mappe
- Lese mappesignaler (heuristiske tolkninger av mappenavn og innhold)
- Se nylig endrede filer
- Se varsler og skanningsbegrensninger
- Navigere mellom mapper og filer for detaljer

**Designkonsekvens:**  
Prosjektoversikten er standard startpunkt etter at en prosjektkontekst er valgt. Leseoperasjoner skal aldri antyde at de skriver noe.

---

### Strukturere

Brukeren gjennomfører en konkret, eksplisitt skriveoperasjon på en avgrenset del av prosjektet. Strukturere-handlinger er alltid synlige, alltid bekrefter seg selv, og lar alltid brukeren se hva som vil skje før det skjer.

**Primære aktiviteter:**
- Importere en transkripsjonsfil til prosjektets transkripsjonmappe
- Opprette en ny prosjektmappe med startstruktur

**Designkonsekvens:**  
Strukturere-handlinger skal se annerledes ut enn lesehandlinger. Enhver skriveoperasjon viser destinasjon, filnavn og konsekvens før den utføres. Bekreftelse er nødvendig for alle handlinger som kopierer eller oppretter filer.

---

### Produsere / Assistere

Brukeren ber Sidekick produsere noe nytt fra prosjektmaterialet, eller utføre en kontrollert AI-operasjon mot prosjektmappen.

Alle operasjoner i denne modusen krever eksplisitt bekreftelse eller forhåndsvisning. Brukeren vet alltid hvilken mappe det gjelder, hva som vil produseres, og i hvilken modus.

**Primære aktiviteter:**
- Forhåndsvise og generere en kontekstpakke
- Kjøre en kontrollert Codex-operasjon (lesemodus eller redigeringsmodus)
- Se strømmende output fra Codex
- Avbryte en aktiv Codex-kjøring

**Designkonsekvens:**  
Produsere/Assistere-operasjoner skal alltid vise omfang og modus. Redigeringsmodus skal se merkbart forskjellig ut fra lesemodus. Codex er ikke et generisk skall – grensesnittet skal ikke se ut som en terminal.

---

## Informasjonsprioritering

Disse prioriteringene gjelder for prosjektoversikten – applikasjonens primære skjerm i normal bruk.

| Informasjon | Prioritet | Begrunnelse |
|---|---|---|
| Aktiv prosjektmappe og full sti | Alltid synlig | Brukeren skal aldri lure på hvilken mappe operasjoner gjelder |
| Mappestruktur og hierarki | Høy | Primær kilde til prosjektforståelse |
| Artefakttyper og antall | Høy | Rask orientering om hva som finnes |
| Varsler og skanningsbegrensninger | Høy | Brukeren må vite når oversikten er ufullstendig |
| Nylig endrede filer | Middels | Kontekstuell aktivitet – nyttig, ikke alltid kritisk |
| Mappesignaler (heuristikk) | Middels | Støtter forståelse, dikterer ikke |
| Metadata på enkeltfiler | Lav | Nyttig ved drill-down, ikke på oversiktsnivå |

---

## Handlingsprioritering

### Primære handlinger
Skal alltid være umiddelbart tilgjengelige og tydelig markert:
- Velge prosjektmappe
- Se / oppdatere prosjektoversikt
- Importere transkripsjon
- Generere kontekstpakke

### Sekundære handlinger
Tilgjengelige, men ikke fremtredende:
- Opprette ny prosjektmappe
- Kjøre Codex-operasjon
- Se detaljer for enkeltmappe eller -fil
- Forhåndsvise kontekstpakke

### Sjeldne handlinger
Tilgjengelige på forespørsel – ikke i hovevenyen:
- Sjekke Codex-tilgjengelighet
- Logge inn i Codex
- Se avanserte skanndetaljer
- Konfigurere skanngrenser

---

## Syv designprinsipper

### 1. Ro fremfor dekor
Visuell støy er den viktigste brukerfrustrasjon med nåværende produkt. Hvert designbeslutning vurderes mot: gjør dette informasjonen lettere å lese, eller legger det til støy? Dekorative elementer, markedsføringspreg og ornamentale kort hører ikke hjemme her.

### 2. Prosjektkontekst er alltid synlig
Brukeren skal aldri måtte sjekke hvilken mappe operasjoner gjelder. Aktiv prosjektmappe og -sti skal alltid fremgå av skjermbildet, uavhengig av hvilken visning eller operasjon som er aktiv.

### 3. Skrivehandlinger er eksplisitte og distinkte
Enhver handling som endrer noe på disk skal (a) se visuelt annerledes ut enn lesehandlinger, (b) vise hva som vil skje og hvor, og (c) kreve bevisst bekreftelse. Skriveoperasjoner skal aldri skje som en bieffekt av navigasjon.

### 4. Progressiv avsløring
Start med oppsummering. La brukeren bore ned. Ikke vis alt på én gang. Oversiktsnivå → mappsnivå → filnivå er en naturlig navigasjonsgradient.

### 5. Statusfeedback uten avbrudd
Fremgang, feil og suksess kommuniseres uten å avbryte arbeidsflyt unødvendig. Kritiske feil kan ta fokus; rutinemessig statusfeedback (skannet, ferdig, oppdatert) skal ikke.

### 6. Lokal-første er synlig i design
Produktet skal aldri antyde at data lastes opp til en sky. Alle operasjoner skjer på brukerens maskin. Språk, ikoner og flyt understreker dette. Unngå sky-metaforer, nettlagrings-estetikk og skjulte bakgrunnsoperasjoner.

### 7. Feil er forståelige og handlingsbare
Feilmeldinger sier hva som gikk galt og hva brukeren kan gjøre. Tekniske feilkoder presenteres aldri uten kontekst. Feil som ikke er brukerens skyld, forklares som det.

---

## Tillitsmodell i interaksjon

Sidekick har skrivetilgang til brukerens lokale filer. Brukeren stoler på produktet fordi produktet er åpent om hva det gjør.

Disse konkrete interaksjonsprinsippene håndhever tillitsmodellen:

**Lesing og skriving er visuelt atskilt.**  
Leseoperasjoner (skanning, visning, navigasjon) er passive og stille. Skriveoperasjoner (import, generering, opprettelse) er synlig markert med skriveindikator, destinasjonsinformasjon og bekreftelse.

**Forhåndsvisning før generering.**  
Operasjoner som genererer eller kopierer filer viser brukeren hva som vil produseres og hvor, før de starter. Forhåndsvisning er alltid tilgjengelig, aldri obligatorisk steg i hurtigflyt.

**Mappevisning i alle skriveoperasjoner.**  
Uansett operasjon vises alltid: hvilken mappe det gjelder, og om relevant, nøyaktig filnavn.

**Ingen destruktive defaults.**  
Produktet skriver aldri over eksisterende filer uten eksplisitt bekreftelse. Konflikter løses automatisk ved å foreslå neste tilgjengelige nummer – brukeren informeres om dette.

**AI-operasjoner har synlig scope og modus.**  
Codex-operasjoner viser alltid hvilken mappe de opererer mot, om de er i lese- eller redigeringsmodus, og om de er aktive. Det skal aldri være uklart hva som kjøres.

**Aktivitetsfeedback uten vage begreper.**  
Statusmeldinger bruker konkrete ord: "Kopierer fil", "Skanner mappe", "Genererer kontekstpakke", "Ferdig – 12 filer inkludert". Ikke: "Behandler…", "AI jobber…", "Vent litt".

---

## Visuell retning (retningslinje for Fase 3)

Disse retningslinjene gjelder for designsystemet som defineres i Fase 3. De er ikke endelige designbeslutninger, men etablerer retning.

**Tetthet:** Kompakt desktop-tetthet. Informasjon skal kunne leses uten scrolling på 1280 × 820. Fontstørrelse 12–13px for kjerneinformasjon er passende; 11px er grense for akseptabel lesbarhet.

**Farge:** Semantisk, ikke dekorativ. Én rolig primærfarge for interaktive elementer. Semantiske farger for feil, advarsel, suksess. Nøytralt for bakgrunn og skjell. Ingen dekorative gradienter. Designsystemet bør ikke hindre mørk modus i fremtiden.

**Typografi:** System-font stack for Windows: `"Segoe UI", Inter, system-ui, sans-serif`. Hierarki gjennom vekt og størrelse, ikke gjennom fargevariasjoner alene.

**Ikoner:** Linjikoner, konsistente strektykke, nøytral farge med semantisk markering ved tilstand. Ikon+etikett-kombinasjon for primære handlinger; ikon alene kun for universelt gjenkjente handlinger.

**Bevegelse:** Begrenset og formålsdrevet. Ingen dekorative animasjoner. Overganger kun der de hjelper brukeren orientere seg (f.eks. skannefremdrift, strømmende output).

**Ikke:**  
Dekorative gradienter · Markedsføringskort · Store tomme flater med illustrasjoner · Chat-estetikk · Overdrevne avrundinger · Skygger som dekorasjon · Vage AI-branding

---

*Fase 1 · Leveranse 1 av 2 · Klar for gjennomgang*
