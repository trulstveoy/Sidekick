# Oppgave 07 – Codex-assistentflyt
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Middels–Høy
**Avhengigheter:** Oppgave 01, Oppgave 06 (kontekstpakke må finnes)
**Estimert kompleksitet:** Høy

---

## Problem

Nåværende Codex-integrasjon kommuniserer ikke tilgjengelighet, autentiseringsstatus eller modus. Brukeren vet ikke om Codex kjøres med lese- eller skrivetilgang, kan ikke avbryte en kjøring, og får minimal feedback under kjøring. Feilmeldinger er tekniske og uforklarlige.

---

## Mål

Implementere en komplett Codex-assistent-flyt med: tilgjengelighetssjekk, eksplisitt modusvalg (lese/skrive), streaming output, avbrytbar kjøring, tydelig resultatsammendrag og håndtering av alle feil- og avbrutt-tilstander. Skrivetilgang skal kreve ekstra bekreftelse og alltid markeres visuelt.

---

## Scope

- Tilgjengelighetssjekk: Codex installert? Autentisert? Modell tilgjengelig?
- Prompt-input med lesetilgang (standard) og skrivetilgang (eksplisitt valg)
- Kjøring med streaming stdout-visning
- Progressindikasjon (filer behandlet / totalt hvis tilgjengelig)
- Avbrytbar kjøring
- Fullført: resultatsammendrag + Codex-svar
- Feil: rate_limit, auth_error, model_not_found, nettverksfeil
- Avbrutt av bruker: delvis resultat + råd
- Kjørelogg: liste over siste kjøringer

---

## Non-goals

- Flerstegs Codex-agentoppgaver
- Lagring av Codex-svar til fil fra Codex-panelet (håndteres av Codex i skrivetilgang)
- Konfigurasjon av Codex-parametere utover modellvalg

---

## Designkrav

### Tilgjengelighetssjekk

Kjøres automatisk første gang Codex-panelet åpnes i en sesjon.

Tre sjekkpunkter vises sekvensielt:
1. Codex CLI installert → ikon OK / feil
2. Autentisert (API-nøkkel) → ikon OK / feil
3. Modell tilgjengelig → ikon OK / venter (grå til 1 og 2 er OK)

**Ikke installert:**
- Feil-kort: «Codex CLI er ikke installert»
- Handling: «Åpne Codex-dokumentasjon» (ekstern lenke)

**Ikke autentisert:**
- Feil-kort: «Codex CLI er ikke autentisert»
- Info om `OPENAI_API_KEY` og/eller `codex login`
- Handling: «Åpne Codex-dokumentasjon», «Sjekk på nytt»

### Prompt-input – Modusvelger

Knapperad med to valg:

| Valg | Badge | Standard |
|------|-------|---------|
| Lesetilgang | Grønn «Anbefalt» | ✓ Ja |
| Skrivetilgang | Amber «Skriveoperasjon» | Nei |

Ved skrivetilgang:
- Amber advarselsboks vises under modusvelgeren
- Tittel: «Codex har skrivetilgang til prosjektmappen»
- Tekst: «Codex kan opprette, endre og slette filer. Disse handlingene kan ikke angres automatisk.»
- Primærknapp endres til danger-variant: «Kjør med skrivetilgang»
- Skriveoperasjon-badge vises i panel-header

### Prompt-textarea

- Plassholder: «Beskriv hva du ønsker at Codex skal gjøre…»
- Tegneller nederst til høyre
- «Tidligere prompts»-knapp (ghost) viser liste over siste 5 prompts i sesjonen
- Feil: tomt felt → knapp deaktivert

### Modellvelger

Nedtrekksliste:
- `o4-mini (rask og rimelig)` – standard
- `o3 (kraftigere)`
- `gpt-4.1`

Modellliste kan hardkodes i første versjon; konfigurerbar i fremtiden.

### Kjøring – Streaming output

**Progressbar** (vises kun hvis Codex gir filantall-data):
- Label: gjeldende operasjon
- Sub-label: fil N av M

**Streaming-terminal:**
- Identisk med kontekstpakke-terminalen (mørk, monospace)
- Live-puls-indikator (grønn) i terminal-header
- Markør blinker på siste linje
- Maks høyde 240px

**Avbryt-knapp:**
- Sekundær, alltid synlig under kjøring
- Etter klikk: sender SIGTERM til Codex-prosessen, viser overgangs-tilstand «Avbryter…»

**Kjøring kan ikke navigeres bort fra** uten advarsel. Hvis bruker forsøker:
- Advarsel-modal: «Codex kjøres fortsatt. Avbryt kjøringen?»
- Handlinger: «Avbryt kjøringen», «Fortsett kjøring»

### Fullført – lesetilgang

- Suksess-banner
- Stats-grid: filer analysert, resultater funnet, kjøretid
- Codex-svar vises som scrollbar tekst-blokk (hvit bakgrunn, 13px)
- Handlinger: «Kjør ny analyse», «Lagre output», «Tilbake»

### Fullført – skrivetilgang

- Suksess-banner: «Codex fullførte og endret filer»
- Tillegg: liste over opprettede/endrede filer med full sti
- Oppfordring til re-skanning: «Skann prosjektet på nytt for å se endringer»

### Feil-tilstander

| Feilkode | Melding |
|----------|---------|
| `rate_limit_error` | «API-kvoten er midlertidig brukt opp. Vent 60 sekunder og prøv igjen.» |
| `auth_error` | «Codex-autentiseringen er ikke lenger gyldig. Sjekk API-nøkkelen din.» |
| `model_not_found` | «Modellen `[modell]` er ikke tilgjengelig. Velg en annen modell.» |
| Nettverksfeil | «Codex er ikke tilgjengelig. Sjekk internettilkoblingen.» |
| Ukjent feil | «Codex stoppet uventet. Ingen filer ble endret.» |

Alltid vis: feil-terminal-output (sammenklappbart), og «Ingen filer ble endret» for lesetilgang.

### Avbrutt av bruker

- Advarsel-banner: «Kjøringen ble avbrutt»
- Stats: N av M filer behandlet, 0 filer endret
- Delvis resultat: informasjonstekst om at analysen er ufullstendig
- Handling: «Kjør på nytt (alle filer)»

### Kjørelogg

- Liste over siste 10 kjøringer i sesjonen
- Kolonner: tidspunkt, modus, modell, status (Fullført/Feil/Avbrutt), filer behandlet
- Klikk på rad: viser output fra den kjøringen (skrivebeskyttet)

---

## Akseptansekriterier

- [ ] Tilgjengelighetssjekk kjøres ved panel-åpning og viser korrekt status
- [ ] Feilmelding ved ikke installert / ikke autentisert med lenke til dokumentasjon
- [ ] «Sjekk på nytt» re-kjører tilgjengelighetssjekken
- [ ] Modusvelger bytter mellom lesetilgang og skrivetilgang
- [ ] Skrivetilgang: amber advarselsboks og danger-knapp er synlige
- [ ] Skrivetilgang: skriveoperasjon-badge i panel-header
- [ ] Tomt prompt-felt deaktiverer kjøre-knappen
- [ ] Kjøring starter Codex CLI med korrekte parametere (modus, modell, kontekstpakke, prompt)
- [ ] Streaming output vises i sanntid i terminalen
- [ ] Avbryt-knapp sender SIGTERM og viser avbrutt-tilstand
- [ ] Navigering bort under kjøring viser advarsel-modal
- [ ] Fullføring (lese): suksess-banner og Codex-svar vises
- [ ] Fullføring (skrive): liste over endrede filer vises
- [ ] Alle feil-typer vises med presis melding og råd
- [ ] Kjørelogg viser de 10 siste kjøringene

---

## Avhengigheter

- Oppgave 01: Designsystem
- Oppgave 06: Kontekstpakke-fil må eksistere
- Codex CLI installert på systemet
- `child_process.spawn` med IPC for stdout-streaming
- Electron `ipcMain`/`ipcRenderer` for prosess-kontroll

---

## Åpne spørsmål

1. Hvoran sendes SIGTERM til Codex-prosessen fra renderer-prosessen? (Via IPC til main-prosessen)
2. Persisteres kjøreloggen mellom sesjoner, eller kun i minnet?
3. Skal «Lagre output» skrive Codex-svaret til en fil i prosjektmappen? Og i så fall med skriveoperasjon-bekreftelse?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `fase3b-ref-codex.html` | Visuell referanse – alle 6+ tilstander |
| `fase3b-skjerm-tilstandsinventar.md` | S06a–S06j |
| `fase3b-terminologi-og-avvik.md` | Terminologi + funksjonelle avvik for Codex |
