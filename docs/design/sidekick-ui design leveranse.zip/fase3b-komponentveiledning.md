# Sidekick – Komponentveiledning
Fase 3b · 11. mai 2026

Dette dokumentet beskriver adferd og visuell behandling for alle gjenbrukbare UI-komponenter i Sidekick. Bruk dette som implementeringsgrunnlag sammen med `fase3b-tokens-v2.json` og `fase3b-tilstandsbibliotek.html`.

---

## 1. Knapper

### 1.1 Primærknapp (`btn-primary`)

**Formål:** Én primærhandling per panel/skjerm. Alltid synlig.

| Tilstand | Bakgrunn | Tekst | Ramme |
|----------|---------|-------|-------|
| Standard | `--accent` (#2D5FA3) | #FFFFFF | `--accent` |
| Hover | `--accent-hover` (#3A72BF) | #FFFFFF | `--accent-hover` |
| Pressed/Active | `--accent-press` (#224A84) | #FFFFFF | `--accent-press` |
| Fokusert | Standard + fokusring | #FFFFFF | Fokusring |
| Deaktivert | Standard + `opacity: 0.45` | #FFFFFF | — |

**Regel:** Maksimalt én primærknapp per skjerm/panel til enhver tid.

**Fokusring:** `outline: 2px solid var(--border-focus); outline-offset: 2px;`

---

### 1.2 Sekundærknapp (`btn-secondary`)

**Formål:** Alternativ handling, tilbake-navigasjon, eksport/lagring.

| Tilstand | Bakgrunn | Tekst | Ramme |
|----------|---------|-------|-------|
| Standard | `--surface` | `--text-1` | `--border-2` |
| Hover | `--bg` | `--text-1` | `--border-3` |
| Fokusert | Standard + fokusring | `--text-1` | Fokusring |
| Deaktivert | Standard + `opacity: 0.45` | — | — |

---

### 1.3 Fare-knapp (`btn-danger`)

**Formål:** Irreversible, destruktive handlinger. Brukes kun for Codex med skrivetilgang.

| Tilstand | Bakgrunn | Tekst | Ramme |
|----------|---------|-------|-------|
| Standard | `--error-icon` (#DC2626) | #FFFFFF | `--error-icon` |
| Hover | #B91C1C | #FFFFFF | #B91C1C |
| Fokusert | Standard + fokusring | #FFFFFF | Fokusring |

**Regel:** Fare-knapper skal aldri være standard-valg. De skal alltid kreve ekstra bekreftelse via advarselstekst og tydelig skriveoperasjon-badge synlig på skjermen.

---

### 1.4 Ghost-knapp (`btn-ghost`)

**Formål:** Tertiærhandlinger, avbryt, tilbake uten kontekst.

| Tilstand | Bakgrunn | Tekst |
|----------|---------|-------|
| Standard | transparent | `--text-2` |
| Hover | `--bg` | `--text-1` |

---

### 1.5 Knappestørrelser

| Størrelse | Font | Padding | Bruk |
|-----------|------|---------|------|
| Standard | 12px | 6px 14px | Standard i handlingsbar og verktøylinje |
| Stor (`btn-lg`) | 13px | 9px 20px | Primærknapp i handlingsbar |
| Liten | 11px | 5px 12px | Panel-header, sidebar |

---

## 2. Inndatafelt (inputs)

### 2.1 Tekstfelt

| Tilstand | Ramme | Bakgrunn |
|----------|-------|---------|
| Standard | `--border-2` | `--surface` |
| Fokusert | `--border-focus` + fokusring | `--surface` |
| Feil | `--error-border` + fokusring i rød | `--error-bg` |
| Suksess | `--success-border` | `--surface` |
| Deaktivert | `--border-1` | `--surface-2` + `opacity: 0.45` |

**Placeholder-tekst:** Bruk `--text-subtle` (#A8A29E). Dette er det **eneste** tillatte bruksområdet for text-subtle i funksjonelt innhold.

**Feilmelding:** Plasseres rett under feltet. Font-size: 11px. Farge: `--error-text`. Foranstilt med ⚠-ikon i `--error-icon`.

---

### 2.2 Prompt-textarea (Codex)

Prompt-feltet er et flerlinje-tekstfelt med utvidet markering for å indikere modus:

- Lesetilgang: standard `--border-2` ramme
- Skrivetilgang: `--warning-border` ramme (amber)
- Fokus: alltid fokusring uavhengig av modus

Plassholder-tekst: `Beskriv hva du ønsker at Codex skal gjøre…`

---

## 3. Modusvelger (mode-selector)

Knapperad for gjensidig utelukkende valg. Brukes i Codex-skjermen.

- Én aktiv tilstand om gangen
- Aktiv: `--accent-s` bakgrunn, `--accent` tekst, font-weight 700
- Inaktiv: `--surface` bakgrunn, `--text-2` tekst
- Ramme mellom knapper: `--border-2`
- Ytterramme: `--border-2`, border-radius 6px

Lesetilgang-badge: grønn (`#DCFCE7` bg, `--success-text` tekst)
Skrivetilgang-badge: amber (`--warning-bg` bg, `--warning-text` tekst)

---

## 4. Listetabeller og rader

### 4.1 Listevisning (mappler, filer)

| Tilstand | Bakgrunn | Tekst | Venstre-markering |
|----------|---------|-------|------------------|
| Standard | transparent | `--text-1` / `--text-2` | Ingen |
| Hover | `--accent-s` | `--text-1` | Ingen |
| Valgt/Aktiv | `--accent-s` | `--accent` | 2px solid `--accent` (venstre kant) |
| Fokusert | Standard + fokusring | — | — |
| Deaktivert | transparent + opacity 0.45 | `--text-3` | Ingen |

**Radklikk:** Navigerer inn (drill-down) eller åpner detalj.
**Rad-høyde:** 36px (kompakt liste), 44px (primærliste med metadata).

---

### 4.2 Hierarkiske rader (expanderbart tre)

Indrykkene bruker faste verdier:
- Toppnivå (depth-0): ingen innrykk, ingen connector
- Dybde 1 (depth-1): `padding-left: 42px` + vertikal connector-linje (`::before` pseudo-element med `border-left: 1px solid var(--border-2)`)
- Dybde 2 (depth-2): `padding-left: 66px` + connector

▶/▾-knapper: 18×18px, `--text-3` farge, ingen synlig ramme, hover viser `--bg` bakgrunn.

---

## 5. Stats-kort (stats-stripe)

Stats-stripe viser 4–7 nøkkeltall i en horisontal rad.

| Element | Spesifikasjon |
|---------|--------------|
| Høyde | 48px |
| Bakgrunn | `--surface` |
| Ramme | border-bottom 1px `--border-1` |
| Kort-bredde | Fleksibel (lik fordeling) |
| Skillelinje | 1px `--border-1` vertikalt mellom kort |
| Tall-font | 16–20px, font-weight 700, `--text-1` |
| Label-font | 10px, `--text-3`, uppercase |
| Accent-tall | Bruk `--accent` for klikk-antall / generert-antall |

---

## 6. Statusbanners

Fire semantiske varianter. Alle følger samme struktur:
`[ikon] [tittel] [brødtekst]`

| Variant | Bakgrunn | Ramme | Tekst | Ikon-farge |
|---------|---------|-------|-------|-----------|
| Suksess | `--success-bg` | `--success-border` | `--success-text` | `--success-icon` |
| Advarsel | `--warning-bg` | `--warning-border` | `--warning-text` | `--warning-icon` |
| Feil | `--error-bg` | `--error-border` | `--error-text` | `--error-icon` |
| Info | `--info-bg` | `--info-border` | `--info-text` | `--info-icon` |

**Regel:** Banners plasseres alltid øverst i panel-body, etter panel-header. Aldri midt i innhold.

**Lukk-knapp:** Valgfri. Ikke nødvendig for kortvarige suksess-meldinger. Påkrevd for vedvarende advarsler brukeren må ta stilling til.

---

## 7. Skriveoperasjons-badge

**Formål:** Kommunisere visuelt at en operasjon skriver til disk.

| Egenskap | Verdi |
|----------|-------|
| Bakgrunn | `--warning-bg` |
| Tekst | `--warning-text`, font-weight 700, 10px |
| Ramme | `--warning-border`, border-radius 4px |
| Ikon | Blyant-ikon i `--warning-icon` |
| Plassering | Panel-header (til høyre for tittel), eller øverst i bekreftelsesskjerm |

**Regel:** Skriveoperasjon-badge **skal alltid** vises i panel-header når en panel håndterer en operasjon som skriver til disk. Den fjernes ikke av brukerhandlinger.

---

## 8. Streaming-terminal

Dark-mode terminal-komponent for Codex-output og Repomix-logg.

| Egenskap | Verdi |
|----------|-------|
| Bakgrunn | #1C1917 |
| Header-bakgrunn | #232120 |
| Standard tekst | #E8E5E2 |
| Dim (bakgrunnslinje) | #6B6864 |
| Info-linje | #60A5FA (blå) |
| OK-linje | #4ADE80 (grønn) |
| Advarselslinje | #FCD34D (gul) |
| Feil-linje | #F87171 (rød) |
| Font | "Cascadia Code", Consolas, monospace · 12px · line-height 1.65 |
| Maks høyde | 240px, deretter scrollbar |
| Bredde | Full bredde av overordnet container |

**Puls-indikator (live):** 7px sirkel i `--success-icon`, CSS-animasjon `pulse` 1.4s.
**Markør:** 7px × 14px blokk, blinkende 0.9s.

---

## 9. Progressbar

| Egenskap | Verdi |
|----------|-------|
| Høyde | 6px |
| Bakgrunn (track) | `--bg`, ramme `--border-1` |
| Fyll | `--accent`, border-radius 3px |
| Animasjon | `transition: width 300ms ease` |
| Label | Over baren: navn på operasjon (font-weight 600) + prosent (høyrejustert) |
| Sub-label | Under baren: `--text-3`, 11px – viser gjeldende fil/steg |

---

## 10. Fokusring (globalt)

**Alle interaktive elementer** skal ha synlig fokusring. Aldri `outline: none` uten alternativ.

```css
:focus-visible {
  outline: 2px solid var(--border-focus);
  outline-offset: 2px;
}
```

`--border-focus` = #2D5FA3 gir 6.2:1 kontrast mot hvit og 5.1:1 mot app-bakgrunn.

**Unntak:** Mus-klikk kan undertrykke `:focus` (bruk `:focus-visible`), men tastaturnavigasjon skal alltid vise fokusring.

---

## 11. Topbar

| Egenskap | Verdi |
|----------|-------|
| Høyde | 44px, alltid synlig |
| Bakgrunn | `--surface` |
| Ramme | border-bottom 1px `--border-1` |
| Logo | 22×22px ikon + tekst, `--text-1` |
| Prosjektkontekst | Mellom logo og høyrehandlinger. Format: `[prosjektnavn] [sti]` |
| Modus-knapper | Høyrejustert, `btn-topbar`-variant |
| Aktiv modus | `--accent-s` bakgrunn, `--accent` tekst, `--accent-b` ramme |

---

## 12. Statuslinje

| Egenskap | Verdi |
|----------|-------|
| Høyde | 24px, alltid synlig |
| Bakgrunn | `--bg` |
| Ramme | border-top 1px `--border-1` |
| Font | 11px, `--text-3` |
| Statusprikk | 6px sirkel, farge angir tilstand: grønn/amber/rød |
| Separator | Vertikal `--border-2` linje mellom seksjoner |

---

## 13. Sidebar

| Egenskap | Verdi |
|----------|-------|
| Bredde | 280px (240px ved minimumsvindu) |
| Bakgrunn | `--surface-2` |
| Ramme | border-right 1px `--border-1` |
| Seksjoner | Delt med border-bottom `--border-1` |
| Seksjonshode | 10px, uppercase, `--text-3`, font-weight 700 |
| Navigasjonselement | 36px høyde, 5px border-radius, hover: `--accent-s` |
| Aktiv navigasjonselement | `--accent-s` bg, `--accent` tekst, font-weight 600 |

---

## 14. Kontekstboks (sidebar)

Brukes i sidebar for å vise tilknyttet kontekstpakke.

| Egenskap | Verdi |
|----------|-------|
| Bakgrunn | `--info-bg` |
| Ramme | `--info-border` |
| Border-radius | 6px |
| Label | 10px, uppercase, `--info-text`, font-weight 700 |
| Filnavn | 12px, monospace, `--info-text` |
| Metadata | 11px, `--text-3` |

---

## 15. Tilgjengelighetssjekk-kort (Codex)

Viser ett sjekkpunkt med status.

| Tilstand | Ikon-bakgrunn | Ikon-farge |
|----------|--------------|-----------|
| OK / Bestått | `--success-bg` | `--success-icon` (hake) |
| Advarsel | `--warning-bg` | `--warning-icon` (info) |
| Feil / Ikke bestått | `--error-bg` | `--error-icon` (kryss) |
| Venter/grå | `--bg` | `--border-3` (klokke) |

Venter-tilstand: hele kortet `opacity: 0.5`, ingen handling mulig.

---

## Oppsummering – Hurtigreferanse

| Komponent | Primær token | Referansefil |
|-----------|-------------|-------------|
| Knapper | `--accent`, `--border-2` | `fase3b-tilstandsbibliotek.html` |
| Inndatafelt | `--border-2`, `--border-focus` | `fase3b-tilstandsbibliotek.html` |
| Listevisning | `--accent-s`, `--text-1` | `fase3-ref-prosjektoversikt.html` |
| Stats-stripe | `--surface`, `--border-1` | `fase3-ref-prosjektoversikt.html` |
| Statusbanners | Semantiske tokens | `fase3b-tilstandsbibliotek.html` |
| Skriveoperasjon-badge | `--warning-*` | `fase3-ref-skriveoperasjoner.html` |
| Streaming-terminal | Mørk palett | `fase3b-ref-codex.html` |
| Fokusring | `--border-focus` | `fase3b-tokens-v2.json` |
