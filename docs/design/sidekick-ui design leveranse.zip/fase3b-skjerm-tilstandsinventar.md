# Sidekick – Skjerm- og tilstandsinventar
Fase 3b · 11. mai 2026

Dette dokumentet er en komplett liste over alle skjermbilder, paneler og tilstander i Sidekick-applikasjonen. For hvert skjerm er det angitt formål, brukeroppgave, nøkkelinformasjon, handlinger og alle tilstander.

---

## Oversikt – Skjermkart

```
App
├── S01 – Tom tilstand (ingen prosjektmappe valgt)
│   ├── S01a – Startskjerm
│   └── S01b – Opprett ny prosjektmappe (modal)
│
├── S02 – Skanning pågår
│   ├── S02a – Initiell skanning
│   └── S02b – Re-skanning
│
├── S03 – Prosjektoversikt (arbeidsskjerm)
│   ├── S03a – Standard (flat mapliste)
│   ├── S03b – Expandert hierarki (▶/▾)
│   ├── S03c – Drill-down (inne i undermappe)
│   └── S03d – Søk / filtrering (fremtidig)
│
├── S04 – Transkripsjonsimport
│   ├── S04a – Velg fil
│   ├── S04b – Bekreft import (viser skriveoperasjon)
│   └── S04c – Resultat (vellykket / feil)
│
├── S05 – Kontekstpakke
│   ├── S05a – Forhåndsvisning (ingen eksisterende)
│   ├── S05b – Forhåndsvisning (eksisterende, advarsel)
│   ├── S05c – Generering pågår
│   └── S05d – Ferdig (resultatsummering)
│
├── S06 – Codex-assistent
│   ├── S06a – Tilgjengelighetssjekk (laster)
│   ├── S06b – Ikke installert (feil)
│   ├── S06c – Ikke autentisert (feil)
│   ├── S06d – Klar / prompt-input (lesetilgang)
│   ├── S06e – Klar / prompt-input (skrivetilgang)
│   ├── S06f – Kjøring pågår
│   ├── S06g – Fullført (lesetilgang)
│   ├── S06h – Fullført (skrivetilgang)
│   ├── S06i – Feil (API-feil, nettverksfeil, o.l.)
│   └── S06j – Avbrutt av bruker
│
└── S07 – Generiske tilstander (gjenbrukbare)
    ├── S07a – Generisk feilvisning
    └── S07b – Generisk advarsel (skriveoperasjon)
```

---

## S01 – Tom tilstand

**Formål:** Onboarding – bruker har ikke valgt prosjektmappe ennå.
**Brukeroppgave:** Velg eller opprett prosjektmappe.

### S01a – Startskjerm

| | |
|--|--|
| **Nøkkelinformasjon** | App-navn, enkel forklaring av hva Sidekick gjør |
| **Primærhandling** | Velg eksisterende mappe… |
| **Sekundærhandling** | Opprett ny prosjektmappe… |
| **Laster** | Nei |
| **Feil** | Nei |
| **Kanttilfeller** | Bruker har ingen prosjektmapper fra før (informasjonstekst er generell) |

**Referansefil:** `fase3-ref-tom-tilstand.html`

### S01b – Opprett ny prosjektmappe (modal)

| | |
|--|--|
| **Nøkkelinformasjon** | Felt for prosjektnavn, valg av lagringssted |
| **Primærhandling** | Opprett |
| **Sekundærhandling** | Avbryt |
| **Laster** | Etter klikk: spinner i knapp |
| **Feil** | Ugyldig mappenavn, mappen finnes allerede |
| **Kanttilfeller** | Tillatelsesfeils (skrivebeskyttet disk) |

---

## S02 – Skanning pågår

**Formål:** Systemet leser mappestrukturen. Skrivebeskyttet operasjon.
**Brukeroppgave:** Vente, eventuelt avbryte.

### S02a – Initiell skanning

| | |
|--|--|
| **Nøkkelinformasjon** | Mappe som skannes, antall filer funnet hittil, elapsed tid |
| **Primærhandling** | Avbryt skanning |
| **Sekundærhandling** | Ingen |
| **Laster** | Ja – spinner + progressindikasjon |
| **Feil** | Se under |
| **Suksess** | Navigerer automatisk til S03a |
| **Feil-tilstander** | Tilgangsfeil (manglende lesetillatelse), for stor mappe (advarsel) |
| **Kanttilfeller** | Mappe er tom → tom tilstand i S03 med informasjonsbanner |

**Referansefil:** `wireframe-01-tom-tilstand.html` (skanning-tilstand)

### S02b – Re-skanning

Identisk med S02a, men bruker er allerede inne i applikasjonen. Topbar og statuslinje er synlige, prosjektkontekst er beholdt.

---

## S03 – Prosjektoversikt

**Formål:** Hoved-arbeidsskjerm. Viser mappestruktur og gir tilgang til alle operasjoner.
**Brukeroppgave:** Navigere i innhold, forstå struktur, starte operasjoner.

### S03a – Standard (mappliste)

| | |
|--|--|
| **Nøkkelinformasjon** | Stats-stripe (7 nøkkeltall), mappliste med signal/typer/antall, sidebar med kontekstuell info |
| **Primærhandling** | Klikk rad → drill-down (S03c) |
| **Sekundærhandlinger** | Generer kontekstpakke, Importer transkripsjon, Kjør Codex, Skann på nytt |
| **Laster** | Stats-stripe kan vise skeleton-tilstand under initial lastning |
| **Tom tilstand** | Mappe har ingen undermapper – viser informasjonstekst med råd |
| **Feil** | Skanning mislyktes – feilbanner øverst i listepanelet |

**Referansefil:** `fase3-ref-prosjektoversikt.html`

### S03b – Expandert hierarki

| | |
|--|--|
| **Nøkkelinformasjon** | Samme som S03a, men trestruktur er synlig med ▶/▾-knapper |
| **Ekstra handlinger** | Ekspander alle, Minimer alle |
| **Dybde** | Maks 2 nivåer vises innrykket. Dypere navigeres med drill-down. |

**Referansefil:** `fase3b-mappehierarki.html` (View A)

### S03c – Drill-down (undermappe)

| | |
|--|--|
| **Nøkkelinformasjon** | Breadcrumb-navigasjon, filliste (ext/navn/størrelse/dato) |
| **Primærhandlinger** | Tilbake, Klikk fil → åpne eksternt |
| **Sekundærhandlinger** | Importer transkripsjon (hvis .txt/.md-filer finnes), Generer kontekstpakke |
| **Tom tilstand** | Mappe er tom – informasjonstekst |

**Referansefil:** `fase3b-mappehierarki.html` (View B)

---

## S04 – Transkripsjonsimport

**Formål:** Importere en lydfil/tekstfil og lagre som nummerert transkripsjon.
**Brukeroppgave:** Velg fil, bekreft plassering, importere.
**Skriveoperasjon:** ✅ Ja – filer skrives til disk.

### S04a – Velg fil

| | |
|--|--|
| **Nøkkelinformasjon** | Filopplaster, målmappe-velger |
| **Primærhandling** | Velg fil… (native filvelger) |
| **Sekundærhandling** | Avbryt |
| **Feil** | Filformat ikke støttet, fil for stor |

### S04b – Bekreft import

| | |
|--|--|
| **Nøkkelinformasjon** | Kildefil, destinasjonsmappe, nytt filnavn (med nummerprefikssystem), skriveadvarsels-boks |
| **Primærhandling** | Bekreft import |
| **Sekundærhandling** | Tilbake |
| **Skriveoperasjon-badge** | Alltid synlig |

### S04c – Resultat

**Vellykket:**

| | |
|--|--|
| **Nøkkelinformasjon** | Suksess-banner, ny filsti, antall tegn/ord |
| **Primærhandling** | Se i mappestruktur |
| **Sekundærhandling** | Importer ny transkripsjon |

**Feil:**

| | |
|--|--|
| **Nøkkelinformasjon** | Feil-banner, feiltype (nettverk, tilgang, format) |
| **Primærhandling** | Prøv igjen |
| **Sekundærhandling** | Avbryt |

**Referansefil:** `wireframe-03-transkripsjonimport.html`, `fase3-ref-skriveoperasjoner.html`

---

## S05 – Kontekstpakke

**Formål:** Generere kontekstpakke med Repomix for bruk i Codex.
**Brukeroppgave:** Generer, erstatt eller inspiser kontekstpakke.
**Skriveoperasjon:** ✅ Ja – `<prosjektnavn>.context-package.md` skrives til disk.

### S05a – Forhåndsvisning (ingen eksisterende)

| | |
|--|--|
| **Nøkkelinformasjon** | Hvilke filer som inkluderes, estimert størrelse |
| **Primærhandling** | Generer kontekstpakke |
| **Sekundærhandling** | Tilbake |

### S05b – Forhåndsvisning (eksisterende, advarsel)

| | |
|--|--|
| **Nøkkelinformasjon** | Som S05a + advarselsboks: «Erstatter eksisterende `kunnskapsbase-2025.context-package.md`» |
| **Skriveoperasjon-badge** | Alltid synlig |

### S05c – Generering pågår

| | |
|--|--|
| **Nøkkelinformasjon** | Progressbar, streaming logg fra Repomix |
| **Primærhandling** | Avbryt |
| **Laster** | Ja |

### S05d – Ferdig

| | |
|--|--|
| **Nøkkelinformasjon** | Stats-grid (filer inkludert, filer hoppet over, filstørrelse, genereringstid), liste over hoppede filer |
| **Primærhandling** | Kjør Codex med denne kontekstpakken |
| **Sekundærhandling** | Tilbake til prosjektoversikt |
| **Feil-tilstand** | Repomix feilet – feilbanner med feiltype og råd |

**Referansefil:** `wireframe-04-kontekstpakke.html`, `fase3-ref-skriveoperasjoner.html`

---

## S06 – Codex-assistent

**Formål:** Kjøre Codex CLI med kontekstpakke og bruker-prompt.
**Brukeroppgave:** Formulere instruksjon, velge modus, kjøre analyse eller produksjon.
**Skriveoperasjon:** ✅ Kun i skrivetilgang.

### S06a – Tilgjengelighetssjekk (laster)

| | |
|--|--|
| **Nøkkelinformasjon** | Info-banner «sjekker status», sjekkliste med pending-ikoner |
| **Primærhandling** | Ingen (venter) |
| **Laster** | Ja |

### S06b – Ikke installert

| | |
|--|--|
| **Nøkkelinformasjon** | Feil-kort: Codex CLI ikke funnet på systemet |
| **Primærhandling** | Åpne Codex-dokumentasjon (ekstern lenke) |
| **Sekundærhandling** | Sjekk på nytt |

### S06c – Ikke autentisert

| | |
|--|--|
| **Nøkkelinformasjon** | Advarsel: manglende API-nøkkel / ikke logget inn |
| **Primærhandling** | Åpne Codex-dokumentasjon |
| **Sekundærhandling** | Sjekk på nytt |

### S06d – Prompt-input (lesetilgang)

| | |
|--|--|
| **Nøkkelinformasjon** | Modusvelger (lesetilgang aktiv), prompt-textarea, modellvelger |
| **Primærhandling** | Kjør Codex (lesetilgang) |
| **Sekundærhandling** | Tilbake |
| **Validering** | Tomt prompt-felt → knapp deaktivert |

### S06e – Prompt-input (skrivetilgang)

| | |
|--|--|
| **Nøkkelinformasjon** | Som S06d, men skrivetilgang aktiv: advarselsboks synlig, primærknapp er «fare»-variant |
| **Primærhandling** | Kjør med skrivetilgang (danger-knapp) |
| **Skriveoperasjon-badge** | Alltid synlig i panel-header |

### S06f – Kjøring pågår

| | |
|--|--|
| **Nøkkelinformasjon** | Progressbar (n av N filer), streaming terminal-output |
| **Primærhandling** | Avbryt kjøring |
| **Puls-indikator** | Grønn puls i topbar-status og panel-header |
| **Kan ikke navigere bort** | Nei (eller advarsel hvis bruker prøver) |

### S06g – Fullført (lesetilgang)

| | |
|--|--|
| **Nøkkelinformasjon** | Suksess-banner, statistikk-grid (filer / temaer / tid), Codex-svar (scrollbart) |
| **Primærhandlinger** | Kjør ny analyse, Lagre output |
| **Sekundærhandlinger** | Tilbake til oversikt |

### S06h – Fullført (skrivetilgang)

| | |
|--|--|
| **Nøkkelinformasjon** | Som S06g + liste over filer som ble opprettet/endret |
| **Ekstra info** | «Filene er skrevet til disk» med eksakt sti per fil |

### S06i – Feil

| | |
|--|--|
| **Nøkkelinformasjon** | Feil-banner, feiltype + feilkode, feil-terminal-output |
| **Primærhandling** | Prøv igjen |
| **Sekundærhandling** | Tilbake |
| **Vanlige feiltyper** | `rate_limit_error`, `auth_error`, `model_not_found`, nettverksfeil |

### S06j – Avbrutt av bruker

| | |
|--|--|
| **Nøkkelinformasjon** | Advarsel-banner, statistikk (N av M filer fullført), «ingen filer endret» |
| **Primærhandling** | Kjør på nytt (alle filer) |
| **Sekundærhandling** | Tilbake |

**Referansefil:** `fase3b-ref-codex.html`

---

## S07 – Generiske tilstander

### S07a – Generisk feilvisning

Brukes når en feil oppstår utenfor en spesifikk flyt (f.eks. filsystemet blir utilgjengelig, Electron-feil).

| | |
|--|--|
| **Nøkkelinformasjon** | Rød feil-banner, teknisk feilmelding (kollapsbar), råd for neste steg |
| **Primærhandling** | Prøv igjen / Last inn på nytt |
| **Sekundærhandling** | Rapporter feil (åpner e-post) |

### S07b – Generisk skriveoperasjons-advarsel

Gjenbrukbart komponent som vises **alltid** før en skriveoperasjon bekreftes.

| | |
|--|--|
| **Innhold** | Operasjonsbeskrivelse, nøyaktig filsti(er), «Sidekick kan ikke angre dette» |
| **Trigger** | Enhver operasjon som skriver til disk |
| **Visuelt** | Amber advarselsboks + skriveoperasjon-badge |

---

## Inventarsoppsummering

| Skjerm | Tilstander | Skriveoperasjon |
|--------|-----------|-----------------|
| S01 Tom tilstand | 2 | Nei |
| S02 Skanning | 2 | Nei |
| S03 Prosjektoversikt | 3 (+1 fremtidig) | Nei |
| S04 Transkripsjonsimport | 3 (inkl. feil) | ✅ Ja |
| S05 Kontekstpakke | 4 (inkl. feil) | ✅ Ja |
| S06 Codex-assistent | 10 | ✅ Skrivetilgang |
| S07 Generiske | 2 | Varierer |
| **Totalt** | **26 tilstander** | |
