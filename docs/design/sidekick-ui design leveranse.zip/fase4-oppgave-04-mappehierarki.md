# Oppgave 04 – Mappestruktur og artefaktvisning
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy
**Avhengigheter:** Oppgave 01, Oppgave 03
**Estimert kompleksitet:** Middels–Høy

---

## Problem

Nåværende applikasjon viser en flat liste av toppnivå-mapper uten mulighet til å utforske dypere nivåer. Brukere med reelle prosjektstrukturer (2–4 nivåer) har ingen måte å se hva som finnes inne i en undermappe uten å åpne filutforskeren. Det er ingen kobling mellom mappevalg og tilgjengelige handlinger.

---

## Mål

Gi brukeren mulighet til å utforske hele prosjektstrukturen inne i Sidekick, enten via in-place utvidelse (expanderbart tre) eller ved å navigere inn i en mappe (drill-down). Visningen skal gjøre det enkelt å se hva som finnes, og hvilke handlinger som er relevante for en gitt undermappe.

---

## Scope

- Expanderbart tre i mapplisten (▶/▾-knapper, maks 2 nivåer inline)
- Drill-down-navigasjon: klikk på rad → viser innhold av mappe
- Breadcrumb-navigasjon i drill-down-visning
- Filliste i drill-down: ext, navn, størrelse, dato
- Tilbake-navigasjon (knapp og breadcrumb)
- «Ekspander alle» / «Minimer alle» for treet
- Adaptiv logikk: maks 2 nivåer expandert inline, dypere navigeres med drill-down

---

## Non-goals

- Kontekstmeny (høyreklikk) – fremtidig
- Dra-og-slipp for filflytting – fremtidig (Strukturere-modus)
- Redigering av filer i Sidekick
- Søk i filer

---

## Designkrav

### Expanderbart tre (View A)

**Innrykk:**
- Dybde 0 (toppnivå): ingen innrykk
- Dybde 1: `padding-left: 42px` + vertikal connector-linje (`::before` med `border-left: 1px solid var(--border-2)`)
- Dybde 2: `padding-left: 66px` + connector

**▶/▾-knapp:**
- 18×18px, plassert til venstre for mappenavnet
- Farge: `--text-3`
- Hover: `--bg` bakgrunn, ingen synlig ramme
- Klikk: toggler ekspandert/minimert tilstand
- Ingen knapp for mapper uten undermapper (eller grået ut)

**«Ekspander alle» / «Minimer alle»:**
- Plassert i listehode (høyre side), ghost-variant, 11px

**Tilstand:**
- Ekspandert tilstand huskes innenfor sesjonen
- Ved re-skanning nullstilles ekspandert tilstand

### Drill-down (View B)

**Breadcrumb:**
- Format: `Prosjektoversikt › [Mappe 1] › [Mappe 2]`
- Hvert ledd er klikkbart og navigerer direkte til det nivået
- Skille: `›` i `--text-3`
- Gjeldende nivå: `--text-1`, ikke klikkbart

**Filliste:**
Kolonner: Filtype-badge | Filnavn | Størrelse | Dato sist endret

- Rad-høyde: 36px
- Filtype-badge: 3-bokstavs forkortelse i farget ramme (`.md` = blå, `.pdf` = rød, `.pptx` = oransje, osv.)
- Klikk på fil: åpner filen i standard systemprogram via Electron `shell.openPath`

**Sidebar i drill-down:**
- Viser mappenavn, antall filer, sti
- Knapper: «Importer transkripsjon» (hvis relevant), «Tilbake til oversikt»

### Tomme mapper

- Viser informasjonsmelding: «Denne mappen er tom»
- Forslag-tekst: «Importer en transkripsjon for å komme i gang»

---

## Akseptansekriterier

- [ ] ▶/▾-knapp viser/skjuler undermapper in-place
- [ ] Connector-linje er synlig for dybde-1 og dybde-2 rader
- [ ] «Ekspander alle» ekspanderer alle mapper til dybde 2
- [ ] «Minimer alle» kollapser alle til toppnivå
- [ ] Klikk på mappenavnet (ikke ▶/▾) navigerer til drill-down-visning
- [ ] Breadcrumb er synlig og hvert ledd er klikkbart
- [ ] Filliste viser ext-badge, navn, størrelse og dato for alle filer i mappen
- [ ] Klikk på fil åpner filen i standard systemprogram
- [ ] Tom mappe viser informasjonstekst
- [ ] Tilbake-navigasjon fungerer med knapp og breadcrumb
- [ ] Ekspandert tilstand huskes innen sesjonen
- [ ] «Sist endret»-kolonne skjules i fillisten ved 1040px vindusbredde
- [ ] Tastaturnavigasjon: Tab mellom rader, Enter for klikk, pil høyre/venstre for ekspander/kollaps

---

## Avhengigheter

- Oppgave 01: Designsystem
- Oppgave 03: Skannet prosjektdata tilgjengelig
- Node.js `fs.readdir` for rekursiv mappelesing
- Electron `shell.openPath` for å åpne filer

---

## Åpne spørsmål

1. Skal «klikk på mappenavn» alltid gå til drill-down, eller kun hvis mappen har mange filer?
2. Skal filtype-badges ha konfigurerbar fargekobling, eller er det hardkodet?
3. Hva er grensen for «mange filer» i en mappe før ytelsen påvirkes av in-place expand?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `fase3b-mappehierarki.html` | Visuell referanse – View A (tre) og View B (drill-down) |
| `fase3b-skjerm-tilstandsinventar.md` | S03b og S03c |
