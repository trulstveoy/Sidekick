# Sidekick – Implementasjons-handoff
Fase 4 · Design QA og oppgaveoversikt · 12. mai 2026

---

## Oppgaveoversikt

| # | Oppgave | Prioritet | Avhengigheter | Fil |
|---|---------|-----------|---------------|-----|
| 01 | Designsystem og delte komponenter | 🔴 Høy | Ingen | `fase4-oppgave-01-designsystem.md` |
| 02 | Prosjektinngangserfaring | 🔴 Høy | 01 | `fase4-oppgave-02-prosjektinngang.md` |
| 03 | Prosjektoversikt og forståelse | 🔴 Høy | 01, 02 | `fase4-oppgave-03-prosjektoversikt.md` |
| 04 | Mappestruktur og artefaktvisning | 🔴 Høy | 01, 03 | `fase4-oppgave-04-mappehierarki.md` |
| 05 | Transkripsjonsimport | 🔴 Høy | 01, 03 | `fase4-oppgave-05-transkripsjonimport.md` |
| 06 | Kontekstpakke | 🔴 Høy | 01, 03 | `fase4-oppgave-06-kontekstpakke.md` |
| 07 | Codex-assistentflyt | 🟡 Middels–Høy | 01, 06 | `fase4-oppgave-07-codex-assistent.md` |
| 08 | Globale tilstander | 🔴 Høy (parallell) | 01 | `fase4-oppgave-08-globale-tilstander.md` |

### Anbefalt rekkefølge

```
Sprint 1 – Grunnlag
  01 Designsystem          ← start her, blokkerer alt
  08 Globale tilstander    ← kan starte parallelt med 01

Sprint 2 – Kjerne
  02 Prosjektinngang
  03 Prosjektoversikt

Sprint 3 – Innhold og navigasjon
  04 Mappehierarki
  05 Transkripsjonsimport
  06 Kontekstpakke

Sprint 4 – Assistent
  07 Codex-assistentflyt
```

---

## Design QA-sjekkliste

Bruk denne sjekklisten ved gjennomgang av hver oppgave før ferdigstilling.

### Visuelt

- [ ] Alle farger er hentet fra CSS custom properties – ingen hardkodede hex-verdier
- [ ] Typografiskalaen er fulgt (10/11/13/14/16/20px)
- [ ] Avstand og padding er konsistent med designsystemet
- [ ] Ikonstil er konsistent (Lucide eller tilsvarende SVG-sett, 1.8px stroke-width)
- [ ] Kantlinjer bruker riktig token (`--border-1`, `--border-2`, `--border-3`)

### Tilgjengelighet

- [ ] Fokusring er synlig ved tastaturnavigasjon på alle interaktive elementer
- [ ] `--text-1`, `--text-2`, `--text-3` møter WCAG AA-kontrast mot bakgrunn
- [ ] `--text-subtle` brukes **kun** for placeholder og deaktivert tekst
- [ ] Alle knapper har tilstrekkelig klikkflate (min. 36px)
- [ ] `disabled`-attributt settes på `<button>` – ikke bare visuell effekt
- [ ] Alle bilder og ikoner har `aria-label` eller er `aria-hidden` der de er rent dekorative
- [ ] Leserekkefølge følger visuell rekkefølge

### Interaksjon

- [ ] Primærknapp: maksimalt én synlig per panel
- [ ] Fare-knapp: kun for Codex med skrivetilgang
- [ ] Skriveoperasjon-badge vises i panel-header ved alle skriveoperasjoner
- [ ] Amber advarselsboks vises alltid i bekreftelsestrinnet for skriveoperasjoner
- [ ] «Ingen filer ble endret» bekreftes alltid ved feil i skriveoperasjoner
- [ ] Avbryt-handling er tilgjengelig for alle langvarige operasjoner
- [ ] Escape lukker modaler og panel-overlays

### Tilstander

- [ ] Tom tilstand vises (ikke tomt panel) der innhold kan mangle
- [ ] Ladetilstand vises for alle asynkrone operasjoner
- [ ] Feil-tilstand viser presis melding – ingen teknisk sjargong i primærtekst
- [ ] Suksess-tilstand bekrefter hva som ble gjort
- [ ] Statuslinje oppdateres korrekt for alle tilstander

### Minimumsvindu (1040×720)

- [ ] Stats-stripe viser 4 (ikke 7) nøkkeltall
- [ ] Sidebar er redusert til 240px
- [ ] «Sist endret»-kolonne er skjult i mapplisten
- [ ] Alle primærhandlinger er fortsatt synlige og klikkbare

### Terminologi

- [ ] Alle termer følger `fase3b-terminologi-og-avvik.md`
- [ ] Kontekstpakke er alltid navngitt `<prosjektnavn>.context-package.md`
- [ ] «Lesetilgang» og «skrivetilgang» brukes konsekvent (ikke «read mode» / «edit mode»)
- [ ] Ingen engelske termer brukes i UI-tekster (unntatt «Codex»)

---

## Komplette designleveranser – filregister

### Fase 1
| Fil | Innhold |
|-----|---------|
| `fase1-ux-rammeverk.md` | Arbeidsmodi, designprinsipper, tillitsmodell |
| `fase1-ia-diagram.html` | Informasjonsarkitektur-diagram |

### Fase 2
| Fil | Innhold |
|-----|---------|
| `wireframe-01-tom-tilstand.html` | Tom tilstand, modal, skanning, feil |
| `wireframe-02-prosjektoversikt.html` | Oversikt, stats, sidebar, drill-down |
| `wireframe-03-transkripsjonimport.html` | 3-stegs import-flyt |
| `wireframe-04-kontekstpakke.html` | 4 kontekstpakke-tilstander |

### Fase 3 – Designsystem
| Fil | Innhold |
|-----|---------|
| `fase3b-tokens-v2.json` | Designtokens (farger, typografi, layout) |
| `fase3b-tilstandsbibliotek.html` | Komponenttilstander – visuell referanse |
| `fase3b-komponentveiledning.md` | Adferd og spesifikasjon for 15 komponenter |

### Fase 3 – Referanseskjermer
| Fil | Innhold |
|-----|---------|
| `fase3-ref-tom-tilstand.html` | Tom tilstand |
| `fase3-ref-prosjektoversikt.html` | Prosjektoversikt (arbeidsskjerm) |
| `fase3-ref-skriveoperasjoner.html` | Import, kontekstpakke-resultat |
| `fase3b-mappehierarki.html` | Tre-visning og drill-down |
| `fase3b-ref-codex.html` | Codex-flyt (6 tilstander) |

### Fase 3 – Spesifikasjoner
| Fil | Innhold |
|-----|---------|
| `fase3b-terminologi-og-avvik.md` | Norsk terminologimodell + funksjonelle avvik |
| `fase3b-minimumsopplevelse.md` | 1040×720 minimumsvindu-adferd |
| `fase3b-skjerm-tilstandsinventar.md` | 26 tilstander – komplett inventar |

### Fase 4 – Implementasjons-handoff
| Fil | Innhold |
|-----|---------|
| `fase4-handoff-oversikt.md` | Denne filen – oversikt og QA-sjekkliste |
| `fase4-oppgave-01-designsystem.md` | Designsystem og CSS-tokens |
| `fase4-oppgave-02-prosjektinngang.md` | Tom tilstand og mappevalg |
| `fase4-oppgave-03-prosjektoversikt.md` | Skanning og arbeidsskjerm |
| `fase4-oppgave-04-mappehierarki.md` | Tre og drill-down |
| `fase4-oppgave-05-transkripsjonimport.md` | 3-stegs import-flyt |
| `fase4-oppgave-06-kontekstpakke.md` | Kontekstpakkegenerering |
| `fase4-oppgave-07-codex-assistent.md` | Codex-flyt |
| `fase4-oppgave-08-globale-tilstander.md` | Statuslinje, feil, tomme flater |

---

## Godkjenningsstatus

| Fase | Status |
|------|--------|
| Fase 1 – UX-rammeverk og IA | ✅ Godkjent |
| Fase 2 – Wireframes | ✅ Godkjent |
| Fase 3 – Designretning | ✅ Godkjent |
| Fase 3b – Revisjoner | ✅ Fullført |
| Fase 4 – Handoff | 🔄 Til gjennomgang |

---

*Designleveransen er komplett. Alle artefakter er repo-vennlige Markdown-, HTML- og JSON-filer. Figma er ikke brukt.*
