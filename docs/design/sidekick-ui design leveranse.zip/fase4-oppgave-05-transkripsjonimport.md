# Oppgave 05 – Transkripsjonsimport
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy
**Avhengigheter:** Oppgave 01, Oppgave 03
**Estimert kompleksitet:** Middels

---

## Problem

Import av transkripsjoner er en skriveoperasjon som i nåværende applikasjon ikke kommuniserer tydelig hva som vil skje. Brukeren vet ikke nøyaktig hvilken fil som opprettes, hvor den plasseres, hva den vil hete, eller at dette er en irreversibel handling. Bekreftelsestrinnet er utilstrekkelig.

---

## Mål

Implementere en 3-stegs import-flyt der brukeren alltid vet nøyaktig hva som skrives til disk, og til hvilken sti, før handlingen bekreftes. Skriveoperasjoner skal markeres konsekvent med skriveoperasjon-badge og amber advarsels-boks.

---

## Scope

- Steg 1: Velg kildefil (lyd, tekst eller Markdown)
- Steg 2: Bekreft import (vis kildefil, målmappe, nytt filnavn med nummerprefikssystem)
- Steg 3: Resultat (vellykket med statistikk, eller feil med råd)
- Automatisk nummerering: neste ledige prefiksnummer i målmappen
- Skriveoperasjon-badge og advarsel synlig i steg 2

---

## Non-goals

- Lydtranskripsjons-API (antas å allerede være implementert; dette er UI-laget)
- Batchimport av flere filer
- Redigering av transkripsjon i Sidekick

---

## Designkrav

### Steg 1 – Velg kildefil

- Fil-velger-komponent med dra-og-slipp-sone eller «Velg fil…»-knapp
- Støttede formater vises eksplisitt: `.txt`, `.md`, `.mp3`, `.wav`, `.m4a`
- Ukjent format: feil-melding inline, fil ikke akseptert
- Målmappe-velger: nedtrekksliste over mapper i prosjektet (standard: første `Transkripsjoner`-mappe hvis den finnes)

### Steg 2 – Bekreft import

**Skriveoperasjon-badge** i panel-header, alltid synlig.

**Detaljvisning:**

| Rad | Innhold |
|-----|---------|
| Kildefil | Opprinnelig filnavn og type |
| Destinasjonsmappe | Full relativ sti, f.eks. `01. Transkripsjoner/` |
| Nytt filnavn | F.eks. `07-intervju-navn.md` (med nummerprefikssystem) |
| Handling | «Ny fil opprettes» |

**Amber advarselsboks:**
- Tittel: «Skriveoperasjon»
- Tekst: «Sidekick oppretter filen `[filnavn]` i `[målmappe]`. Ingen andre filer endres.»

Primærknapp: «Bekreft import» (standard blå `.btn-primary`)
Sekundærknapp: «← Tilbake»

### Steg 3a – Vellykket

- Suksess-banner: «Transkripsjonen er importert»
- Fil-sti vist i monospace
- Statistikk: antall tegn, antall ord (hvis tilgjengelig)
- Primærhandling: «Se i mappestruktur»
- Sekundærhandling: «Importer ny transkripsjon»

### Steg 3b – Feil

| Feiltype | Melding |
|----------|---------|
| Tilgangsfeil | «Sidekick har ikke skrivetilgang til denne mappen» |
| Filnavn-konflikt | «En fil med dette navnet finnes allerede. Velg et annet navn.» |
| Nettverksfeil (API) | «Transkripsjonstjenesten er ikke tilgjengelig. Prøv igjen.» |
| Ukjent feil | «Import mislyktes. Ingen filer ble endret.» |

Alltid avslutte med: «Ingen filer ble endret» for å betrygge bruker.

### Nummerprefikssystem

- Les eksisterende filer i målmappen
- Finn høyeste eksisterende prefiksnummer (format `NN-`)
- Foreslå neste ledige: `(høyeste + 1)`, nullpolstret til 2 siffer
- Eksempel: finnes `01-`, `02-`, `04-` → foreslår `05-` (ikke `03-`)
- Bruker kan ikke endre prefiksnummeret manuelt (unngå konflikter)

---

## Akseptansekriterier

- [ ] Steg 1: filvelger aksepterer støttede formater og avviser andre med presis melding
- [ ] Steg 2: viser kildefil, destinasjonsmappe, nytt filnavn og skriveoperasjon-badge
- [ ] Steg 2: amber advarselsboks er alltid synlig
- [ ] Steg 2: «Bekreft»-knapp skriver filen kun etter klikk
- [ ] Nummerprefikssystem beregner korrekt neste nummer
- [ ] Steg 3 (suksess): suksess-banner og filsti vises
- [ ] Steg 3 (feil): feilmelding angir type feil og bekrefter at ingen filer ble endret
- [ ] «← Tilbake» fra steg 2 returnerer til steg 1 uten å gjøre endringer
- [ ] Hele flyten er tastaturnavigerbar (Tab, Enter, Escape)
- [ ] Skriveoperasjon-badge er synlig i panel-header gjennom hele flyten fra steg 2

---

## Avhengigheter

- Oppgave 01: Designsystem (badge, banner, knapper)
- Oppgave 03: Prosjektstruktur (mappliste for målmappevalg)
- Node.js `fs.writeFile`, `fs.readdir` for nummerering og filskriving
- Eksisterende transkripsjons-API (antas tilgjengelig)
- Electron `dialog.showOpenDialog` for filvelger

---

## Åpne spørsmål

1. Skal bruker kunne redigere det foreslåtte filnavnet (utover prefikset)?
2. Håndteres transkripsjons-API-kall i Sidekick, eller er det en ekstern prosess?
3. Skal det finnes en «Siste importerte» visning i sidebar?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `wireframe-03-transkripsjonimport.html` | Wireframe for alle tre steg |
| `fase3-ref-skriveoperasjoner.html` | Visuell referanse – bekreftelse og suksess |
| `fase3b-skjerm-tilstandsinventar.md` | S04a, S04b, S04c |
| `fase3b-terminologi-og-avvik.md` | Terminologi for import + funksjonelle avvik |
