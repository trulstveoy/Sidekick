# Oppgave 06 – Kontekstpakke
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy
**Avhengigheter:** Oppgave 01, Oppgave 03
**Estimert kompleksitet:** Middels

---

## Problem

Generering av kontekstpakken er en kritisk skriveoperasjon som i nåværende applikasjon gir minimal feedback. Brukeren vet ikke hvilke filer som inkluderes, ser ingen fremgang under generering, og får bare en vag bekreftelse. Når en eksisterende kontekstpakke skal erstattes, kommuniseres ikke dette tydelig. Filnavnet er ikke alltid korrekt.

---

## Mål

Implementere en tydelig 4-tilstands flyt for kontekstpakkegenerering: forhåndsvisning (hva inkluderes), advarsel ved erstatning, generering med synlig fremgang og streaming logg, og et nyttig resultatsammendrag. Brukeren skal alltid vite nøyaktig hva som skrives til disk.

---

## Scope

- Tilstand A: Forhåndsvisning – hva vil bli inkludert, outputfilnavn
- Tilstand B: Forhåndsvisning med erstatningsadvarsel (kontekstpakke finnes)
- Tilstand C: Generering pågår – progressbar + streaming logg fra Repomix
- Tilstand D: Ferdig – stats-grid, liste over hoppede filer
- Feil-tilstand: Repomix mislyktes

---

## Non-goals

- Konfigurasjon av hvilke filer som inkluderes (Repomix-standard brukes)
- Visning av kontekstpakkens innhold inne i Sidekick
- Versjonering av kontekstpakker

---

## Designkrav

### Filnavn

Kontekstpakken **skal alltid** navngis etter mønsteret:
```
<prosjektnavn>.context-package.md
```
Eksempel: `kunnskapsbase-2025.context-package.md`

Prosjektnavnet hentes fra mappenavnet og normaliseres (mellomrom → bindestrek, lowercase). Filnavnet vises eksplisitt i forhåndsvisningen.

### Tilstand A – Forhåndsvisning (ingen eksisterende)

Tabell:

| Rad | Innhold |
|-----|---------|
| Outputfil | `<prosjektnavn>.context-package.md` (monospace) |
| Skrivested | Prosjektrot (relativ sti) |
| Eksisterende | «Ingen – ny fil opprettes» |
| Omfang | «Alle tekstfiler i prosjektmappen» |
| Estimert antall filer | N filer |

**Skriveoperasjon-badge** i panel-header.
Primærknapp: «Generer kontekstpakke»

### Tilstand B – Forhåndsvisning med erstatningsadvarsel

Identisk med A, pluss:
- Amber advarselsboks: «Kontekstpakken `[filnavn]` vil erstattes med en ny versjon. Den gamle versjonen kan ikke gjenopprettes automatisk.»
- Eksisterende fil-rad: filnavn + størrelse + dato

### Tilstand C – Generering pågår

**Progressbar:**
- Label: «Genererer kontekstpakke…»
- Prosent: beregnes fra Repomix-output (filer behandlet / totalt)
- Sub-label: gjeldende fil

**Streaming-terminal:**
- Mørk bakgrunn (#1C1917)
- Viser Repomix stdout i sanntid
- Linje-farger: dim (grå), info (blå), ok (grønn), warn (gul), err (rød)
- Maks høyde 240px, deretter scrollbar

**Avbryt-knapp:** sekundær, alltid synlig under generering.

### Tilstand D – Ferdig

**Stats-grid (2×2 eller 2×3):**

| Tall | Etikette |
|------|----------|
| N | Filer inkludert |
| N | Filer hoppet over |
| N KB/MB | Filstørrelse |
| N sek | Genereringstid |

**Liste over hoppede filer:**
- Tittel: «Hoppet over (N filer)»
- Hver rad: filnavn + årsak (f.eks. «binærfil», «for stor», «ekskludert av .repomixignore»)

**Primærhandling:** «Kjør Codex med denne kontekstpakken» (navigerer til Oppgave 07)
**Sekundærhandling:** «Tilbake til prosjektoversikt»

### Feil-tilstand

- Feil-banner: «Generering mislyktes»
- Feiltype vist
- «Ingen filer ble endret» bekreftes alltid
- Handling: «Prøv igjen»

---

## Akseptansekriterier

- [ ] Filnavnet følger mønsteret `<prosjektnavn>.context-package.md` i alle tilstander
- [ ] Forhåndsvisning viser outputfil, skrivested og antall filer før generering
- [ ] Advarselsboks vises når eksisterende kontekstpakke vil erstattes
- [ ] Skriveoperasjon-badge er synlig i panel-header
- [ ] Progressbar og streaming logg vises under generering
- [ ] Avbryt-knapp er synlig og fungerer under generering
- [ ] Stats-grid viser inkluderte filer, hoppede filer, størrelse og tid etter fullføring
- [ ] Liste over hoppede filer vises med årsak
- [ ] «Kjør Codex»-knapp er synlig og fungerer etter fullføring
- [ ] Feil-tilstand bekrefter at ingen filer ble endret
- [ ] Stats-stripe i prosjektoversikt oppdateres etter vellykket generering

---

## Avhengigheter

- Oppgave 01: Designsystem (streaming-terminal, progressbar, badge, stats-grid)
- Oppgave 03: Prosjektdata (filantall, prosjektnavn)
- Repomix CLI / bibliotek
- IPC for streaming av Repomix-output til renderer-prosessen

---

## Åpne spørsmål

1. Kjøres Repomix som et CLI-tool via `child_process`, eller er det integrert som et npm-bibliotek?
2. Sender Repomix fremgangsdata på stdout, eller er det bare en slutt-melding?
3. Skal `.repomixignore` vises og redigeres i Sidekick? (Foreslås som fremtidig utvidelse)

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `wireframe-04-kontekstpakke.html` | Wireframe for alle tilstander |
| `fase3-ref-skriveoperasjoner.html` | Visuell referanse – generert resultat |
| `fase3b-skjerm-tilstandsinventar.md` | S05a–S05d |
| `fase3b-terminologi-og-avvik.md` | Filnavnmønster + funksjonelle avvik |
