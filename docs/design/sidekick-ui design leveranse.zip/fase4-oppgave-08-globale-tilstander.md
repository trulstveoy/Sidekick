# Oppgave 08 – Globale tilstander
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy (parallell med andre oppgaver)
**Avhengigheter:** Oppgave 01 (designsystem)
**Estimert kompleksitet:** Middels

---

## Problem

Globale tilstander – feil, varsler, fremgang og aktivitetsfeedback – er håndtert uensartet og ufullstendig i nåværende applikasjon. Noen operasjoner gir ingen feedback, andre viser tekniske feilmeldinger. Det finnes ingen konsistent mekanisme for å kommunisere langvarige operasjoner eller systemtilstand.

---

## Mål

Definere og implementere et konsistent sett av globale tilstandsmønstre som alle oppgaver kan bruke: statuslinje, operasjonsfeedback, generisk feilvisning, skriveoperasjon-advarsel og tomme flater. Mønstre implementeres én gang og gjenbrukes konsekvent.

---

## Scope

- Statuslinje: persistent bunnlinje med operasjonsstatus
- Aktivitetsfeedback: hva skjer nå (tekst + puls)
- Generisk feilvisning: komponent for uventede feil
- Generisk skriveoperasjons-advarsel: gjenbrukbar komponent
- Tomme flater: mønster for «ingenting her ennå»
- Toast-notifikasjoner: korte, selvforsvinende meldinger (valgfritt, se nedenfor)
- Ladetilstander: spinner og skeleton-varianter
- Tastaturfelle-håndtering (Escape for å lukke panel/modal)

---

## Non-goals

- Push-notifikasjoner fra operativsystemet
- Logg-visning av all historisk aktivitet (kjørelogg håndteres i Oppgave 07)
- Feilrapportering til ekstern tjeneste

---

## Designkrav

### Statuslinje (24px, alltid synlig)

Format: `[●] [Primærstatus] | [Sekundærstatus]`

Statusprikk-farger:
- Grønn: klar, ingen aktiv operasjon
- Amber: operasjon pågår, advarsel
- Rød: feil, Codex ikke autentisert

Eksempler:

| Tilstand | Statuslinje-tekst |
|----------|------------------|
| Klar | `● Kunnskapsbase 2025 · 84 filer · Klar` |
| Skanner | `● Skanner mappestruktur…` |
| Genererer kontekstpakke | `● Genererer kontekstpakke…` |
| Codex kjøres (lese) | `● Codex kjøres · lesetilgang · 00:00:23` |
| Codex kjøres (skrive) | `● Codex kjøres · skrivetilgang · 00:00:23` |
| Feil | `● Feil: rate_limit_error` |
| Ingen prosjekt | `Ingen aktiv prosjektkontekst` |

Tidsteller under Codex-kjøring oppdateres hvert sekund.

### Generisk feilvisning (S07a)

Brukes for uventede systemfeil som ikke har spesifikk behandling i en annen oppgave.

Struktur:
- Feil-banner (rød) med tittel og kort beskrivelse
- Teknisk detalj: sammenklappbar seksjon med feilkode / stack trace (for avansert feilsøking)
- Handling: «Prøv igjen» og/eller «Last inn applikasjonen på nytt»

Feil-banner-innhold:
- Tittel: «Noe gikk galt»
- Tekst: kort, handlingsorientert – aldri teknisk sjargong i primær-tekst
- «Ingen filer ble endret» vises alltid hvis operasjonen var en skriveoperasjon

### Generisk skriveoperasjons-advarsel (S07b)

Gjenbrukbart komponent som vises **alltid** før enhver skriveoperasjon bekreftes, uavhengig av hvilken flyt som kaller det.

Props/parametere:
- `operationDescription`: kort setning om hva som vil skje
- `filePaths`: liste over filer som berøres (relativ sti)
- `cannotUndo`: boolsk – vises alltid som `true` i Sidekick

Visning:
- Amber advarselsboks
- Skriveoperasjon-badge
- `operationDescription` som brødtekst
- Liste over `filePaths`
- Tekst: «Sidekick kan ikke automatisk angre denne handlingen.»

### Tomme flater

Brukes i: mapper uten innhold, søk uten treff, kjørelogg uten historikk, o.l.

Struktur:
- Sentrert ikon-wrapper (52×52px, `--surface-2` bakgrunn)
- Overskrift: 14px, font-weight 600, `--text-1`
- Brødtekst: 12px, `--text-2`, maks 300px bredde
- Valgfri handlingsknapp

Eksempler:

| Kontekst | Overskrift | Brødtekst |
|----------|-----------|-----------|
| Tom mappe | «Denne mappen er tom» | «Importer en transkripsjon for å komme i gang» |
| Kjørelogg tom | «Ingen kjøringer ennå» | «Kjør Codex for å se resultater her» |
| Ingen varsler | «Ingen varsler» | «Prosjektet ser strukturert ut» |

### Ladetilstander

**Spinner:** 20px sirkel, `--accent` farge, rotasjon 0.8s. Brukes for kortvarige operasjoner (< 2 sekunder).

**Skeleton-loader:** Grå plass-holdere med animert shimmer. Brukes for stats-stripe og mappliste under initial lastning. Animasjon: `background: linear-gradient(90deg, --border-1, --border-2, --border-1)`, beveger seg over elementet.

**Regel:** Vis aldri et tomt panel – vis alltid enten innhold, skeleton eller tom-tilstand.

### Toast-notifikasjoner (valgfritt i første versjon)

Kortvarige meldinger i øvre høyre hjørne. Levid: 4 sekunder, fadeout 0.3s.

- Suksess: grønn bakgrunn, hvit tekst
- Advarsel: amber
- Feil: rød

Brukes for: «Kontekstpakke generert», «Import fullført», «Codex fullført». Hvis toast ikke implementeres i første versjon, brukes banner i panel-body i stedet.

### Tastaturhåndtering

Globale snarveier (Electron `globalShortcut` eller renderer event-handler):

| Tast | Handling |
|------|---------|
| `Escape` | Lukk åpen modal, avbryt aktiv panel-overlay |
| `F5` | Skann på nytt |
| `Ctrl+,` | Åpne innstillinger (fremtidig) |

Escape skal **ikke** avbryte en pågående Codex-kjøring uten bekreftelse (se Oppgave 07).

---

## Akseptansekriterier

- [ ] Statuslinje oppdateres korrekt for alle operasjonsstilstander
- [ ] Statusprikk endrer farge korrekt (grønn/amber/rød)
- [ ] Tidsteller vises og oppdateres under Codex-kjøring
- [ ] Generisk feil-banner vises for uventede feil med presis, ikke-teknisk primærtekst
- [ ] Teknisk detalj er tilgjengelig via sammenklappbar seksjon
- [ ] Skriveoperasjons-advarsel er implementert som gjenbrukbart komponent
- [ ] Tom-tilstand-mønster er implementert og brukes konsekvent der innhold mangler
- [ ] Spinner-komponent brukes for kortvarige operasjoner
- [ ] Skeleton-loader brukes for stats-stripe og mappliste ved initial lastning
- [ ] Escape lukker åpne modaler og panel-overlays
- [ ] F5 starter re-skanning fra prosjektoversikten
- [ ] Aldri et tomt panel uten innhold, skeleton eller tom-tilstand

---

## Avhengigheter

- Oppgave 01: Designsystem (tokens, banner-varianter, badge)
- Alle andre oppgaver bruker disse mønstrene

---

## Åpne spørsmål

1. Skal toast-notifikasjoner implementeres i første versjon, eller er banner i panel tilstrekkelig?
2. Skal det finnes en global feil-log som bruker kan se? (Foreslås som fremtidig utvidelse)
3. Kan Electron `ipcMain` sende globale statusoppdateringer til statuslinjen direkte, uavhengig av aktiv skjerm?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `fase3b-tilstandsbibliotek.html` | Visuell referanse – alle komponenttilstander |
| `fase3b-komponentveiledning.md` | Statuslinje, feil-banner, tomme flater |
| `fase3b-skjerm-tilstandsinventar.md` | S07a og S07b |
| `fase3b-tokens-v2.json` | Semantiske fargetokens for tilstandsvarianter |
