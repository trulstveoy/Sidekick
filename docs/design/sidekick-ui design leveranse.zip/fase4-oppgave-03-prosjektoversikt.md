# Oppgave 03 – Prosjektoversikt og forståelse
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy
**Avhengigheter:** Oppgave 01 (designsystem), Oppgave 02 (prosjektinngang)
**Estimert kompleksitet:** Høy

---

## Problem

Nåværende prosjektoversikt viser en flat filliste uten prioritering eller kontekst. Brukeren kan ikke raskt forstå hva prosjektet inneholder, hva som er nylig endret, eller hva som eventuelt mangler. Det finnes ingen statistikk-visning, ingen signalmekanisme og ingen måte å skille mellom mappe-typer.

---

## Mål

Gi brukeren et øyeblikksbilde av prosjektstatus: antall filer, mapper, artefakttyper og relevante advarsler. Skanning skal starte automatisk ved valg av mappe og gi umiddelbar feedback. Oversikten skal kommunisere struktur og status uten at brukeren må åpne enkeltfiler.

---

## Scope

- Initiell skanning av prosjektmappe (S02a) med avbryt-funksjon
- Re-skanning (S02b) – «Skann på nytt» fra prosjektoversikten
- Stats-stripe med 4–7 nøkkeltall
- Mappliste med kolonner: navn, signal, filtyper, antall filer
- Sidebar med kontekstuell informasjon: nylig endret, varsler, skanningsstatus
- Handlingsbar med primære operasjoner
- Topbar med persistent prosjektnavn og sti
- Statuslinje med operasjonsstatus
- Tom tilstand: prosjektmappe er tom
- Feil-tilstand: skanning mislyktes

---

## Non-goals

- Hierarkisk mappeutforsking (Oppgave 04)
- Søk og filtrering (fremtidig)
- Direkte redigering av filer i Sidekick
- Sortering av mapplisten (fremtidig)

---

## Designkrav

### Topbar (alltid synlig)

Format: `[Logo] [Prosjektnavn] [sti, forkortet] … [Modus-knapper]`

- Prosjektnavn: `--text-1`, font-weight 600
- Sti: `--text-3`, 11px, forkortes med `…` ved 1040px
- Modus-knapper: Forstå / Strukturere / Assistere – aktiv modus markert med `--accent-s` bakgrunn

### Skanning – tilstand under kjøring

- Enkel spinner-visning sentrert i innholdspanelet
- Tekst: «Skanner [mappenavn]…»
- Antall filer funnet hittil (telles opp i sanntid hvis mulig)
- Avbryt-knapp: sekundær, alltid synlig under skanning
- Avbrutt skanning: advarsel-banner «Skanningen ble avbrutt – oversikten er ufullstendig»

### Stats-stripe (48px)

7 nøkkeltall ved 1280px, 4 ved 1040px:

| Tall | Etikette | Alltid synlig |
|------|----------|---------------|
| Totalt antall filer | Filer | ✓ |
| Antall mapper | Mapper | ✓ |
| Dato for siste skanning | Siste skanning | ✓ |
| Kontekstpakke-status | Kontekstpakke | ✓ |
| Størrelse på disk | Diskstørrelse | Skjules ved 1040px |
| Antall transkripsjoner | Transkripsjoner | Skjules ved 1040px |
| Antall varsler | Varsler | Skjules ved 1040px |

- Kontekstpakke-status: «Klar» (grønn) / «Mangler» (amber) / «Utdatert» (amber)
- Varsler > 0: vist med `--warning-icon`-farge

### Mappliste

Kolonner: Mappenavn | Signal | Filtyper | Antall filer | [Sist endret – skjules ved 1040px]

- Rad-høyde: 36px
- Signalkolonne: ikon for advarsel (`--warning-icon`) eller OK (ingen ikon)
- Filtype-badges: småe fargemerker (f.eks. `.md`, `.pdf`, `.pptx`)
- Rad-hover: `--accent-s` bakgrunn
- Rad-klikk: navigerer inn i mappe (Oppgave 04)
- Tom tilstand: informasjonsmelding «Denne prosjektmappen inneholder ingen undermapper»

### Sidebar (280px)

Seksjoner:
1. **Nylig endret** – liste over 3–5 nylig endrede filer med dato
2. **Varsler** – filer/mapper uten nummerprefikssystem, tomme mapper, o.l.
3. **Skanningsstatus** – tidspunkt for siste skanning, antall filer

### Handlingsbar (52px)

- Primær: «Generer kontekstpakke» (`.btn-primary`)
- Sekundær: «Importer transkripsjon»
- Sekundær: «Kjør Codex»
- Høyrejustert: «Skann på nytt» (ghost-knapp med ikon)

### Feil-tilstand (skanning mislyktes)

- Feil-banner øverst i listepanelet
- Melding: «Skanningen mislyktes: [feiltype]»
- Handling: «Prøv igjen»

---

## Akseptansekriterier

- [ ] Skanning starter automatisk etter valg av prosjektmappe
- [ ] Skannings-tilstand viser spinner og løpende filantall
- [ ] Avbryt-knapp er synlig og fungerer under skanning
- [ ] Stats-stripe viser 7 nøkkeltall ved 1280px og 4 ved 1040px
- [ ] Mappliste viser alle toppnivå-mapper med navn, signal, filtyper og antall
- [ ] Rad-hover og rad-klikk fungerer
- [ ] Sidebar viser nylig endrede filer og eventuelle varsler
- [ ] Topbar viser prosjektnavn og sti til enhver tid
- [ ] Statuslinje oppdateres i sanntid under skanning og etter ferdigstilling
- [ ] Tom prosjektmappe viser informasjonstekst i listepanelet
- [ ] Feil-tilstand viser presis feilmelding med «Prøv igjen»-handling
- [ ] «Skann på nytt» starter re-skanning uten at bruker forlater oversikten
- [ ] Alle nøkkelhandlinger (generer, importer, Codex, skann) er tilgjengelige med tastatur

---

## Avhengigheter

- Oppgave 01: Designsystem
- Oppgave 02: Prosjektinngang (mappe er valgt før denne kjøres)
- Node.js `fs.readdir` med rekursjon for skanning
- IPC-kanal for fremgang under skanning (fil-for-fil oppdatering)

---

## Åpne spørsmål

1. Hvilke advarsler skal vises i signalkolonnen? (Foreslås: manglende nummerprefikssystem, tomme mapper, duplikatfiler)
2. Skal skanning skje i bakgrunnen ved oppstart, eller kun på eksplisitt forespørsel etter første gang?
3. Hva er maks antall filer før skanning gir ytelsesvarsel?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `fase3-ref-prosjektoversikt.html` | Visuell referanse for arbeidsskjerm |
| `wireframe-02-prosjektoversikt.html` | Wireframe inkl. stats og sidebar |
| `fase3b-skjerm-tilstandsinventar.md` | S02a, S02b, S03a |
| `fase3b-minimumsopplevelse.md` | Stats-stripe ved 1040px |
