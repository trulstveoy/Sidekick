# Oppgave 01 – Designsystem og delte komponenter
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy – blokkerer alle andre oppgaver
**Avhengigheter:** Ingen (startpunkt)
**Estimert kompleksitet:** Høy

---

## Problem

Applikasjonen mangler et konsistent visuelt grunnlag. Farger, typografi, avstand og komponentstiler er uensartede, noe som resulterer i visuell støy og gjør fremtidige endringer kostbare. Det finnes ingen delte komponentprimitiver, så like elementer implementeres ulikt på tvers av skjermer.

---

## Mål

Etablere et komplett CSS-basert designsystem som alle øvrige UI-komponenter bygges på. Systemet skal håndtere alle visuelle tilstander, møte WCAG AA-krav og gjøre det mulig å endre utseende ett sted uten å jakte på hardkodede verdier.

---

## Scope

- CSS custom properties (variabler) for alle tokens definert i `fase3b-tokens-v2.json`
- Typografi-skala og font-stack
- Basiskomponenter: knapper (primær, sekundær, fare, ghost), inndatafelt, modusvelger
- Delte layout-primitiver: topbar, statuslinje, sidebar, panel, handlingsbar, stats-stripe
- Fokusring-implementasjon (global `:focus-visible`-regel)
- Skriveoperasjon-badge
- Statusbanners (suksess, advarsel, feil, info)
- Progressbar
- Streaming-terminal-komponent (mørk, monospace)
- Statusprikk (grønn/amber/rød)

---

## Non-goals

- Mørk modus (tokens skal ikke hindre det, men mørk modus implementeres ikke nå)
- Animasjoner utover progressbar-overgang og fokusring
- Ikonpakke – bruk Lucide eller tilsvarende SVG-basert sett
- Responsivt design under 1040px

---

## Designkrav

### Fargetokens
Alle farger hentes fra CSS custom properties. Ingen hardkodede fargeverdier i komponentkode.

```css
/* Kjerne */
--bg: #F4F3F1;
--surface: #FFFFFF;
--surface-2: #F9F8F7;
--border-1: #E2DFD9;
--border-2: #C0BCB5;
--border-3: #9E9A92;
--border-focus: #2D5FA3;
--text-1: #1C1917;
--text-2: #57534E;
--text-3: #64625E;
--text-subtle: #A8A29E;
--accent: #2D5FA3;
--accent-hover: #3A72BF;
--accent-press: #224A84;
--accent-subtle: #EBF0FA;
--accent-border: #9DBDE8;
/* Semantiske: --success-*, --warning-*, --error-*, --info-* */
```

Full liste: se `fase3b-tokens-v2.json`.

### Typografi
- Font-stack: `"Segoe UI", Inter, system-ui, -apple-system, sans-serif`
- Mono-stack: `"Cascadia Code", Consolas, monospace`
- Skala: 10px (xs), 11px (sm), 13px (base), 14px (md), 16px (lg), 20px (xl)
- Brødtekst: 13px, line-height 1.55
- UI-etiketter: 12px
- Seksjonsoverskrifter: 11px, uppercase, letter-spacing 0.6px

### Kontrastkrav
- `--text-1` mot `--bg`: 14.7:1 (AAA) ✓
- `--text-2` mot `--bg`: 6.2:1 (AA) ✓
- `--text-3` mot `--bg`: 4.7:1 (AA) ✓
- `--text-subtle` (#A8A29E): KUN placeholder-tekst og deaktiverte elementer – unntas AA-krav
- `--accent` mot hvit: 6.2:1 (AA) ✓

### Fokusring
```css
:focus-visible {
  outline: 2px solid var(--border-focus);
  outline-offset: 2px;
}
```
Aldri `outline: none` uten alternativ. `:focus-visible` foretrekkes fremfor `:focus` for å unngå mus-ring.

### Knapper
Se `fase3b-komponentveiledning.md` seksjon 1 for fullstendig tilstandstabell.

Nøkkelregel: Maksimalt én `.btn-primary` synlig per panel/skjerm. Fare-knapper (`.btn-danger`) brukes kun for Codex med skrivetilgang.

### Deaktivert tilstand
```css
[disabled], .disabled {
  opacity: 0.45;
  cursor: not-allowed;
  pointer-events: none;
}
```
Sett alltid `disabled`-attributt på `<button>` – aldri bare visuell effekt.

---

## Akseptansekriterier

- [ ] Alle farger er implementert som CSS custom properties; ingen hardkodede hex-verdier i komponentkode
- [ ] Fokusring vises tydelig ved tastaturnavigasjon på alle interaktive elementer
- [ ] Primærknapp, sekundærknapp, fare-knapp og ghost-knapp har korrekte hover-, pressed- og deaktivert-tilstander
- [ ] Inndatafelt har korrekte ramme- og fokus-tilstander (standard, fokus, feil, deaktivert)
- [ ] Statusbanners (4 varianter) viser korrekt farge, ikon og tekst
- [ ] Skriveoperasjon-badge er implementert som gjenbrukbart komponent
- [ ] Streaming-terminal viser korrekte linje-varianter (dim, info, ok, warn, err)
- [ ] Kontrast for `--text-1`, `--text-2`, `--text-3` møter AA mot `--bg` og `--surface`
- [ ] `--text-subtle` brukes kun for placeholder og deaktivert tekst
- [ ] Applikasjonen er brukbar med kun tastatur (Tab, Enter, Space, Escape)
- [ ] Vindu kan ikke dras under 1040×720 (sett `minWidth`/`minHeight` i Electron)

---

## Avhengigheter

Ingen. Denne oppgaven er forutsetning for alle andre.

---

## Åpne spørsmål

1. Skal CSS custom properties settes globalt i `:root` eller i et overordnet Electron-vinduselement?
2. Er Lucide Icons det foretrukne ikonsettet, eller er det en preferanse?
3. Skal det brukes et CSS-preprosessorverktøy (Sass, PostCSS), eller ren CSS?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `fase3b-tokens-v2.json` | Komplett token-spesifikasjon med kontrastverdier |
| `fase3b-tilstandsbibliotek.html` | Visuell referanse for alle komponenttilstander |
| `fase3b-komponentveiledning.md` | Adferdsbeskrivelse for alle komponenter |
