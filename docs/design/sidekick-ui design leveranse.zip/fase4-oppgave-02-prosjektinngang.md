# Oppgave 02 – Prosjektinngangserfaring
Sidekick GUI-refresh · Implementasjons-handoff · Fase 4

**Prioritet:** Høy
**Avhengigheter:** Oppgave 01 (designsystem)
**Estimert kompleksitet:** Middels

---

## Problem

Første gang en bruker starter Sidekick møter de en udifferensiert startside uten kontekst. Det er uklart hva Sidekick gjør, hva en «prosjektmappe» er, og hva som skjer etter at man velger en mappe. Det finnes ingen tydelig skille mellom «velg eksisterende» og «opprett ny», og ingenting kommuniserer at applikasjonen er lokal og fil-orientert.

---

## Mål

Gi brukeren en klar, tillitvekkende inngangserfaring som forklarer hva Sidekick er, gjør det enkelt å velge eller opprette en prosjektmappe, og kommuniserer at ingen filer endres før brukeren aktivt velger det.

---

## Scope

- Tom tilstand: skjerm uten aktiv prosjektmappe (sentrert kort)
- Valg av eksisterende mappe (native filvelger via Electron `dialog.showOpenDialog`)
- Modal for opprettelse av ny prosjektmappe (mappenavn + lagringssted)
- Overgangstilstand etter valg: «Kobler til mappe…» (laster)
- Feil-tilstander: mappe ikke funnet, tilgangsfeil, ugyldig mappetype
- Persistens: sist brukte mappe huskes mellom sesjoner

---

## Non-goals

- Onboarding-wizard eller flerstegs innføring
- Skanning (håndteres i Oppgave 03)
- Prosjektliste / nylig brukte mapper (kan vurderes som fremtidig utvidelse)

---

## Designkrav

### Tom tilstand – sentrert kort

- App-bakgrunn: `--bg` (#F4F3F1)
- Hvitt kort: 440px bredt, `--surface`, `--border-2`-ramme, border-radius 10px
- Mappe-ikon: 52×52px ikon-wrapper med `--surface-2` bakgrunn
- Overskrift: 15px, font-weight 600, `--text-1`
- Brødtekst: 12px, `--text-2`, maks 320px bredde, line-height 1.55
- Primærknapp: «Velg eksisterende mappe…» – full bredde
- Skille: «eller» med horisontale linjer
- Sekundærknapp: «Opprett ny prosjektmappe…» – full bredde
- Topbar og statuslinje er synlige («Ingen aktiv prosjektkontekst»)

### Opprett ny mappe – modal

- Sentrert overlay (ikke fullskjerm-panel)
- Maks bredde: 480px
- Felt 1: Prosjektnavn (tekstfelt, påkrevd, validering: kun gyldige tegn)
- Felt 2: Lagringssted (sti-felt med «Velg…»-knapp som åpner Electron-filvelger)
- Eksempel på resulterende sti vises live under feltene
- Primærhandling: «Opprett» (deaktivert til begge felt er valide)
- Sekundærhandling: «Avbryt»
- Skriveoperasjon: Opprettelse av mappe er en skriveoperasjon – bekreftelsestekst under knapp: «En tom mappe opprettes på valgt sted.»

### Prosjektnavn-validering

- Tillatte tegn: bokstaver, tall, mellomrom, bindestrek, understrek
- Maks lengde: 64 tegn
- Feilmelding ved ugyldig: «Prosjektnavnet inneholder ugyldige tegn»
- Feilmelding ved duplikat (mappe finnes): «En mappe med dette navnet finnes allerede på valgt sted»

### Ladetilstand etter valg

Etter at bruker velger mappe, vises en overgangs-tilstand:
- Sentrert spinner
- Tekst: «Kobler til [mappenavn]…»
- Ingen interaksjon mulig (ikke-modal, ikke avbrytbar i denne fasen)
- Maks varighet: 3 sekunder, deretter navigeres til Oppgave 03 (skanning)

### Feil-tilstander

| Feil | Melding |
|------|---------|
| Mappe finnes ikke lenger | «Mappen ble ikke funnet. Velg en annen mappe.» |
| Tilgangsfeil | «Sidekick har ikke lesetilgang til denne mappen. Sjekk tillatelser.» |
| Systemfeil | «Noe gikk galt. Prøv igjen.» |

Alle feil vises som feil-banner i toppen av kortet, ikke som modal.

---

## Akseptansekriterier

- [ ] Tom tilstand vises ved oppstart når ingen prosjektmappe er valgt
- [ ] «Velg eksisterende mappe…» åpner Electron native filvelger for mappevalg
- [ ] «Opprett ny prosjektmappe…» åpner modal med navn- og lagringssted-felt
- [ ] Prosjektnavn valideres i sanntid med feilmelding
- [ ] «Opprett»-knapp er deaktivert til alle felt er valide
- [ ] Ladetilstand vises etter valg av mappe
- [ ] Sist brukte mappe huskes og tilbys som snarvei ved neste oppstart (kan implementeres som persistert preferanse)
- [ ] Feil-tilstander vises med presis melding – ingen tekniske stack traces
- [ ] Hele flyten er navigerbar med tastatur (Tab, Enter, Escape lukker modal)
- [ ] Fokus setter seg i prosjektnavnfeltet når modalen åpnes
- [ ] Escape lukker modalen uten å gjøre endringer

---

## Avhengigheter

- Oppgave 01: Designsystem (CSS tokens, knapper, inndatafelt, feil-banner)
- Electron `dialog.showOpenDialog` og `dialog.showSaveDialog` (eller tilsvarende IPC)
- Node.js `fs.mkdir` / `fs.access` for opprettelse og validering av mappe

---

## Åpne spørsmål

1. Skal «nylig brukte mapper» vises i tom tilstand? (Foreslås som fremtidig utvidelse, ikke nå)
2. Hvordan persisteres sist valgte mappe? (Electron `app.getPath('userData')` + JSON-fil anbefales)
3. Er det ønskelig med en «Pinne»-mekanisme for å huske flere prosjekter?

---

## Referansefiler

| Fil | Formål |
|-----|--------|
| `fase3-ref-tom-tilstand.html` | Visuell referanse for tom tilstand |
| `wireframe-01-tom-tilstand.html` | Wireframe inkl. modal og ladetilstand |
| `fase3b-skjerm-tilstandsinventar.md` | S01a og S01b |
