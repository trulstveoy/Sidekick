# Sidekick – Terminologi og funksjonelle avvik
Fase 3b · 11. mai 2026

---

## Del 1 – Terminologimodell (norsk)

Dokumentet fastlegger alle norske termer som brukes i Sidekick-grensesnittet. Alle disse termene skal brukes konsekvent på tvers av UI, dokumentasjon og kode-kommentarer.

### Kjernebegreper

| Term i UI | Aldri bruk | Forklaring |
|-----------|------------|------------|
| **Prosjektmappe** | Prosjekt, workspace, arbeidsplass | Den lokale mappen som Sidekick er knyttet til. En mappe på disk, ikke et konsept i en database. |
| **Skann / skanning** | Indeksering, crawling, analyse | Prosessen der Sidekick leser mappestrukturen uten å endre filer. Alltid skrivebeskyttet. |
| **Kontekstpakke** | kontekst.md, context, sammendrag | Filen som genereres av Repomix. Alltid på formen `<prosjektnavn>.context-package.md`. |
| **Transkripsjonsimport** | Opplasting, import, overføring | Prosessen der en lydfil konverteres til tekst og nummereres med prefiks-systemet. |
| **Nummerprefikssystem** | Nummering, sortering, rekkefølge | Konvensjonen `00.`, `01.`, `02.` osv. som mapper og filer navngis med for å opprettholde rekkefølge. |
| **Codex-kjøring** | Codex-prompt, AI-analyse, kjøring | Én utførelse av Codex CLI med en gitt prompt og kontekstpakke. |
| **Lesetilgang** | Lesemodus, read-only, skrivebeskyttet | Codex-modus der ingen filer endres. Standard og anbefalt. |
| **Skrivetilgang** | Skrivetilstand, edit mode, redigering | Codex-modus der Codex kan opprette, endre og slette filer. Krever eksplisitt valg. |
| **Skriveoperasjon** | Lagreoperasjon, filskriving, edit | Enhver handling som resulterer i at data skrives til disk. Markeres alltid tydelig i UI. |
| **Kjørelogg** | Historikk, logg, aktivitetslogg | Liste over alle tidligere Codex-kjøringer i en session. |
| **Streaming-output** | Live-output, sanntidslogg, terminal | Den kontinuerlige tekst-outputen som vises mens Codex kjøres. |
| **Tilstandsbibliotek** | Komponentbibliotek, designsystem | Referansevisning for alle komponenttilstander. Intern designterm. |
| **Mappestruktur** | Filtre, hierarki, directory tree | Den trestrukturerte visningen av prosjektmappens innhold. |
| **Mappehierarki** | Filstruktur, mappenivåer | Samme som mappestruktur. Benyttes i IA-dokumenter. |
| **Forstå** | Analyse-modus, lese-modus | Én av tre arbeidsmodi. Fokus: lese og forstå innholdet i prosjektmappen. |
| **Strukturere** | Organisere-modus, rydde-modus | Én av tre arbeidsmodi. Fokus: flytte, navngi og organisere filer. |
| **Assistere** | Produsere, AI-modus, Codex-modus | Én av tre arbeidsmodi. Fokus: bruke Codex til å analysere eller produsere innhold. |

### Filnavn og stier

| Mønster | Eksempel | Aldri bruk |
|---------|---------|------------|
| `<prosjektnavn>.context-package.md` | `kunnskapsbase-2025.context-package.md` | `kontekst.md`, `context.md`, `<prosjektnavn>.md` |
| `<nn>-<beskrivende-navn>.<ext>` | `05-intervju-ane-marie.md` | Filer uten nummerprefikssystem |
| `<NN>. <Mappenavn>/` | `01. Transkripsjoner/` | `transkripsjoner/`, `01_transkripsjoner/` |

### Systemstatuser (statuslinje)

| Tilstand | Tekst i statuslinje |
|----------|---------------------|
| Ingen prosjektmappe valgt | `Ingen aktiv prosjektkontekst` |
| Prosjekt lastet, klar | `<prosjektnavn> · <antall> filer · Klar` |
| Skanning pågår | `Skanner mappestruktur…` |
| Kontekstpakke genereres | `Genererer kontekstpakke…` |
| Codex kjøres (lesetilgang) | `Codex kjøres · lesetilgang · <tid>` |
| Codex kjøres (skrivetilgang) | `Codex kjøres · skrivetilgang · <tid>` |
| Feil | `Feil: <kort beskrivelse>` |

---

## Del 2 – Funksjonelle avvik

Denne delen dokumenterer hvilke funksjoner som finnes i dag (POC), og hvilke som er nye forslag i dette designet. Avviket er viktig å kommunisere tydelig til implementering.

### Kategorier

- **✅ Eksisterende** – Finnes i dag i POC-applikasjonen
- **🆕 Nytt forslag** – Designet i Fase 3, ikke implementert
- **🔄 Revidert** – Eksisterende funksjon med nytt/forbedret design
- **⚠️ Avhengig** – Avhenger av annen ny funksjon

---

### Prosjektmappe og skanning

| Funksjon | Status | Merknad |
|----------|--------|---------|
| Velg eksisterende mappe | ✅ Eksisterende | |
| Opprett ny prosjektmappe | ✅ Eksisterende | |
| Skann mappestruktur (flat) | ✅ Eksisterende | Viser bare toppnivå |
| Skann mappestruktur (hierarkisk, drill-down) | 🆕 Nytt forslag | Se `fase3b-mappehierarki.html` |
| Vis mappe-stats (antall filer, typer, varsler) | 🔄 Revidert | Ny stats-stripe i stedet for tekstliste |
| **Avbrytbar skanning** | 🆕 Nytt forslag | Avbryt-knapp under skanning. POC venter til ferdig. |
| Automatisk re-skanning ved filendring | 🆕 Nytt forslag | Watch-mekanisme ikke i POC |
| Prosjektnavn og sti alltid synlig (topbar) | 🆕 Nytt forslag | POC mangler persistent prosjektkontekst |

---

### Kontekstpakke (Repomix)

| Funksjon | Status | Merknad |
|----------|--------|---------|
| Generer kontekstpakke | ✅ Eksisterende | Kaller Repomix |
| Vis genereringsstatus | 🔄 Revidert | Ny progressbar + streaming logg |
| **Streaming logg under generering** | 🆕 Nytt forslag | POC viser ingen fremgang. Krever IPC fra backend. |
| Vis filstatistikk etter generering | 🔄 Revidert | Nytt stats-grid i stedet for tekstmelding |
| Vis hoppede filer | 🆕 Nytt forslag | Liste over filer Repomix utelot og hvorfor |
| Erstatt eksisterende kontekstpakke (med advarsel) | 🔄 Revidert | Advarsel finnes i POC, ny visuell behandling |
| Korrekt filnavn: `<prosjektnavn>.context-package.md` | ✅ Eksisterende | Mønsteret er korrekt, men design brukte forenklet navn – nå rettet |

---

### Transkripsjonsimport

| Funksjon | Status | Merknad |
|----------|--------|---------|
| Velg lydfil for import | ✅ Eksisterende | |
| Transkripsjonstjeneste (ekstern API) | ✅ Eksisterende | |
| Automatisk nummerprefikssystem | ✅ Eksisterende | |
| 3-stegs bekreftelsesflyten (velg → bekreft → resultat) | 🔄 Revidert | POC har enklere flyt |
| Vis kildefil, målmappe, nytt navn eksplisitt | 🆕 Nytt forslag | Ny bekreftelsesskjerm viser alle detaljer |
| Skriveoperasjons-badge og advarselsboks | 🆕 Nytt forslag | POC varsler ikke tydelig at filer skrives |

---

### Codex-assistent

| Funksjon | Status | Merknad |
|----------|--------|---------|
| Kall Codex CLI | ✅ Eksisterende | |
| Prompt-input | ✅ Eksisterende | |
| **Lesetilgang vs. skrivetilgang som eksplisitt valg** | 🆕 Nytt forslag | POC bruker alltid skrivetilgang uten å kommunisere dette |
| Tilgjengelighetssjekk (installert / autentisert) | 🆕 Nytt forslag | POC feiler uten forklaring hvis Codex ikke er konfigurert |
| Streaming output under kjøring | ✅ Eksisterende | Delvis – POC viser output, men ikke strukturert |
| Progressbar med filnavn | 🆕 Nytt forslag | |
| Avbrytbar kjøring | 🆕 Nytt forslag | POC kan ikke avbryte en kjøring midtveis |
| Resultatsammendrag (statistikk-grid) | 🆕 Nytt forslag | |
| Kjørelogg (historikk over kjøringer) | 🆕 Nytt forslag | |
| Modellvalg i UI | 🆕 Nytt forslag | POC har hardkodet modell |
| Feilhåndtering med feiltype og råd | 🔄 Revidert | POC viser rå feilmelding |

---

### Navigasjon og visning

| Funksjon | Status | Merknad |
|----------|--------|---------|
| Tre arbeidsmodi (Forstå / Strukturere / Assistere) | 🆕 Nytt forslag | POC er ikke organisert etter modus |
| Stats-stripe med 7 nøkkeltall | 🆕 Nytt forslag | |
| Sidebar med kontekstuell info | 🔄 Revidert | POC har sidebar, men med annen logikk |
| Expanderbart mappehierarki (▶/▾) | 🆕 Nytt forslag | POC viser flat liste |
| Drill-down navigasjon med breadcrumb | 🆕 Nytt forslag | |

---

### Minimumsvindu (1040×720)

Se eget dokument: `fase3b-minimumsopplevelse.md`

---

## Del 3 – Begreper som IKKE skal brukes i UI

Disse termene har vært i bruk i POC eller i tidligere designdokumenter, men skal erstattes med godkjente norske termer:

| Unngå | Bruk i stedet |
|-------|--------------|
| workspace | prosjektmappe |
| context | kontekstpakke |
| index / indexing | skanning |
| prompt | instruksjon (i UI), prompt (i teknisk logg) |
| edit mode | skrivetilgang |
| read mode | lesetilgang |
| run / kjøring | Codex-kjøring |
| `kontekst.md` | `<prosjektnavn>.context-package.md` |
| AI | Codex (spesifikt) eller assistent (generisk) |
| upload | import (for transkripsjoner) |
| save | lagre (kun hvis bruker eksplisitt lagrer) |
| sync | skann på nytt |
