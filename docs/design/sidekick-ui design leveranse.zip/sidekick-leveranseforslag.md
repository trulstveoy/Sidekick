# Leveranseforslag: Sidekick GUI-refresh

**Fra:** Design- og interaksjonskonsulent  
**Til:** Sidekick-produktteam  
**Status:** Forslag til gjennomgang – ikke endelig leveranse  
**Dato:** 11. mai 2026

---

## Innledning

Dette er mitt forslag til leveranse for GUI-refreshen av Sidekick. Forslaget beskriver hvilke designartefakter jeg anbefaler å produsere, på hvilket fidelitetsnivå, i hvilken rekkefølge, og hva jeg trenger fra dere for å komme i gang.

Formålet med dette dokumentet er å etablere en felles forståelse av leveransen før detaljert designarbeid starter. Jeg ber om at dere gjennomgår og kommenterer dette forslaget, slik at vi kan justere kurs før jeg investerer tid i screens og spesifikasjoner.

---

## Sammendrag av min forståelse av produktet

Sidekick er et lokalt, fillbasert skrivebordsverktøy for kunnskapsarbeid. Kjerneoppgaven er å hjelpe brukeren forstå, organisere og arbeide med prosjektmapper på disk – ikke å erstatte filutforskeren, terminalen eller et generisk AI-chatgrensesnitt.

AI-funksjonalitet er et hjelpemiddel, ikke produktets identitet. Tillitsmodellen er lokal og eksplisitt. Det viktigste designprinsippet er at brukeren alltid vet hva som skjer med filene sine.

Refreshen skal gjøre applikasjonen roligere, tydeligere og mer formålsrettet – ikke legge til dekor eller omforme produktet til noe det ikke er.

---

## Anbefalte designartefakter

### 1. UX- og produktrammeverk (tekst + diagram)
**Fidelitet:** Konseptuell – skisser og prosa  
**Formål:** Etablere felles forståelse av arbeidsmodi, informasjonshierarki og prioritering av handlinger  
**Innhold:**
- Beskrivelse av de tre primære arbeidsmodi: *Inspiser*, *Organiser*, *Generer/Kjør*
- Prioritering av hva som er primære, sekundære og sjeldne handlinger
- Beskrivelse av hvordan lokal tillitsmodell kommuniseres gjennom interaksjon
- Overordnet prinsipper for leseretning og informasjonstetthet

---

### 2. Informasjonsarkitektur (IA-diagram)
**Fidelitet:** Strukturdiagram (ikke visuell design)  
**Formål:** Definere hvordan applikasjonens funksjonelle områder henger sammen  
**Innhold:**
- Navigasjonsmodell og skjermhierarki
- Inngangsflyt for ny prosjektkontekst og eksisterende mappe
- Strukturering av prosjektforståelse (oversikt → mappe → fil)
- Plassering av import-, genererings- og assistentoperasjoner i strukturen
- Hvor feil, varsler og aktivitetstilstander befinner seg

---

### 3. Arbeidsflytskisser / Wireflows
**Fidelitet:** Gråtone wireframes med annotasjoner – ikke polert visueldesign  
**Formål:** Definere alle nødvendige skjermtilstander og overganger  
**Dekker følgende arbeidsflyter:**

| Arbeidsflyt | Prioritet |
|---|---|
| Start uten aktiv prosjektkontekst (tom tilstand) | Høy |
| Velge eksisterende prosjektmappe | Høy |
| Opprette ny prosjektmappe | Høy |
| Forstå skannet prosjekt (oversikt) | Høy |
| Utforske mappe- og artefaktinformasjon | Høy |
| Importere transkripsjon | Høy |
| Forhåndsvisning av kontekstpakke | Høy |
| Generere kontekstpakke | Høy |
| Kontrollere Codex-tilgjengelighet og innloggingsstatus | Middels |
| Kjøre skrivebeskyttet Codex-operasjon | Middels |
| Kjøre redigeringsmodus Codex-operasjon | Middels |
| Avbryte Codex-operasjon | Middels |
| Forstå suksess-, advarsel- og feiltilstander | Høy |

Wireflows inkluderer alle relevante tilstander per skjerm: tom, laster, suksess, feil, advarsel, kant-case.

---

### 4. Skjerm- og tilstandsinventar
**Fidelitet:** Strukturert tekstdokument med referanser til wireframes  
**Formål:** Komplett liste over alle skjermbilder, paneler, dialoger og tilstander som designet krever  
**Per tilstand beskrives:**
- Formål
- Primær brukeroppgave
- Nøkkelinformasjon
- Primære handlinger
- Sekundære handlinger
- Tom tilstand
- Ladetilstand
- Feiltilstand
- Suksesstistand
- Kant-caser

---

### 5. Visuelt designsystem
**Fidelitet:** Spesifikasjonsdokument med token-verdier  
**Formål:** Definere det visuelle språket for applikasjonen – tilpasset et skrivebords-produktivitetsverktøy  
**Innhold:**
- Fargepalett (primær, nøytral, semantisk: advarsel, feil, suksess, info)
- Typografi (font, skala, vekt, linjehøyde)
- Avstandsskala (spacing tokens)
- Tetthetsregler (kompakt, standard)
- Ikonsstil og anbefalinger
- Kantlinjer og skillelinjer
- Elevasjon/skygge (minimal, for skrivebordsbruk)
- Fokustilstander (tydelig, tilgjengelig)
- Valgstilstander
- Deaktivert tilstand
- Advarsel- og feilbehandling
- Suksess- og fremgangsbehandling
- Bevegelse/animasjon (begrenset, formålsdrevet)

---

### 6. Komponentveiledning
**Fidelitet:** Annoterte skisser + atferdsbeskrivelser  
**Formål:** Definere gjenbrukbare interaksjonsmønstre og komponenter  
**Komponenter som spesifiseres:**
- Prosjektselektor og prosjektinngangsmønster
- Mappe- og artefaktutforsker
- Metadataoppsummering
- Handlingsområder (primær, sekundær, farlig)
- Forhåndsvisning/bekreftelsesmønster for skriveoperasjoner
- Advarsel- og feilvisning
- Fremdrifts- og strømmende-output-visning
- Filimportmønster
- Kontekstpakke-resultatvisning
- Kontrollert assistent-kjøremønster
- Innstillinger/statuspanel for eksterne verktøy (Codex)

---

### 7. Tilgjengelighet og skrivebordsergonomi
**Fidelitet:** Retningslinjedokument  
**Innhold:**
- Tastaturnavigasjon og fokusrekkefølge
- Synlige fokustilstander
- Kontrast og lesbare typstørrelser
- Tilpasning ved endret vinduestørrelse
- Høytetthetsmodus
- Redusert bevegelse
- Skjermlesermerking for kritiske tilstander
- Native skrivebordsnormer (meny, snarveier, høyreklikk)

---

### 8. Innhold og terminologi
**Fidelitet:** Ordliste og mikrokopi-retningslinjer  
**Innhold:**
- Navn på nøkkelbegreper (norsk/engelsk der relevant)
- Handlingsetiketter
- Statusspråk
- Feilspråk
- Advarselsspråk
- Bekreftelsesspråk
- Terminologi for AI-assisterte operasjoner
- Terminologi for kontekstpakkegenerering
- Terminologi for transkripsjonsimport

---

### 9. Implementasjons-handoff
**Fidelitet:** Annoterte designs + token-verdier + oppgavespesifikasjoner  
**Innhold:**
- Annoterte wireframes/designs med mål og spacing
- Design tokens (farge, typografi, avstand)
- Komponentspesifikasjoner med tilstandsbeskrivelser
- Interaksjonsnotes
- Akseptansekriterier per oppgave
- Design QA-sjekkliste
- Åpne spørsmål og forutsetninger

---

## Anbefalt sekvens for arbeidet

```
Fase 1 – Fundament (2–3 dager)
  ├── UX- og produktrammeverk
  └── Informasjonsarkitektur

  → Gjennomgang med dere

Fase 2 – Arbeidsflyt og tilstander (4–6 dager)
  ├── Wireflows (høyprioriterte arbeidsflyter)
  └── Skjerm- og tilstandsinventar

  → Gjennomgang med dere

Fase 3 – Visuelt system og komponenter (3–4 dager)
  ├── Visuelt designsystem
  └── Komponentveiledning

  → Gjennomgang med dere

Fase 4 – Tilgjengelighet, innhold og handoff (2–3 dager)
  ├── Tilgjengelighet og skrivebordsergonomi
  ├── Innhold og terminologi
  └── Implementasjons-handoff + oppgavespesifikasjoner
```

Gjennomgangspunkter er viktige: resultater fra Fase 1 påvirker Fase 2, og jeg vil ikke investere tid i detaljerte wireframes før IA-modellen er godkjent.

---

## Foreslått oppgavestruktur for implementasjonen

Basert på min forståelse av produktet foreslår jeg at GUI-refreshen deles i disse implementasjonsoppgavene:

1. **Visuelt designsystem og delte komponenter** – farger, typografi, spacing, fokus/seleksjon/deaktivert
2. **Prosjektinngangserfaringen** – velge og opprette prosjekt, tom tilstand
3. **Prosjektoversikt og mappeforståelse** – skannet prosjektvisning, signaler, statistikk
4. **Artefakt- og mappeutforsker** – tredelt hierarki, metadatavisning
5. **Transkripsjonimport-arbeidsflyt** – import, nummerering, bekreftelse
6. **Kontekstpakke-arbeidsflyt** – forhåndsvisning, generering, resultat
7. **Kontrollert Codex-assistentarbeidsflyt** – tilgjengelighetssjekk, kjøring, strøm, avbryt
8. **Globale tilstander** – feil, advarsler, fremgang, tomme tilstander
9. **Tilgjengelighet og tastaturinteraksjon** – fokus, snarveier, lesbarhet

Hver oppgave vil bruke task-spesifikasjonsformatet som er beskrevet i briefen.

---

## Informasjon jeg trenger fra dere før oppstart

### Nødvendig (blokker oppstart)
- [ ] **Skjermbilder eller demo av nåværende app** – for å forstå eksisterende kapabiliteter, ikke som mal for redesign
- [ ] **Hva er det viktigste problemet med nåværende UI?** – hvilke konkrete frustrasjoner opplever brukeren i dag?
- [ ] **Primær plattform** – macOS, Windows, eller begge? Påvirker native mønstre og forventninger

### Nyttig (bør avklares tidlig)
- [ ] **Vinduestørrelsesintervall** – hva er typisk og minimum vindusbredde og -høyde?
- [ ] **Spesifikke fargealternativer** – har dere en eksisterende merkevare som bør reflekteres, eller full frihet?
- [ ] **Eksisterende ikonbibliotek?** – brukes et spesifikt ikonsett i dag?
- [ ] **Mørk modus-krav** – er dette nødvendig nå, eller kan det planlegges for?
- [ ] **Locale / språk** – er appen på norsk, engelsk, eller begge?
- [ ] **Typisk prosjektstørrelse** – hvor mange filer/mapper bør UI tåle å vise elegant?

### Ønskelig (kan avklares underveis)
- [ ] **Produktvision-dokument** – dersom tilgjengelig
- [ ] **Arkitekturdokumentasjon** – særlig for IPC-grensesnitt mellom main og renderer
- [ ] **Eksisterende oppgavelogger** – for å forstå hva som allerede er planlagt teknisk

---

## Hva som gjennomgås etter første iterasjon

Etter Fase 1 (UX-rammeverk og IA) ber jeg om at dere vurderer:

1. **Er primære arbeidsmodi riktig identifisert?** – inspeksjon, organisering, generering/kjøring
2. **Er informasjonshierarkiet riktig?** – hva er viktigst på en prosjektoversikt?
3. **Er IA-modellen forståelig for teamet?** – kan utviklerne navigere den?
4. **Er det arbeidsflyter vi har glemt?** – spesielt edge cases dere kjenner til
5. **Er lokale tillitsprinsipper tydelig kommunisert i strukturen?**

---

## Hva er utenfor scope

- Implementasjon av koden
- Ingeniørplaner eller arkitekturbeslutninger
- Valg av biblioteker eller rammeverk
- Redesign av Sidekick som et sky- eller chat-produkt
- Generisk filutforsker-funksjonalitet
- Markedsføring eller onboarding-flyt (med mindre dere ønsker det)
- Utvidet AI-funksjonalitet utover det som er beskrevet i briefen
- Mobilversjon

---

## Format for endelig leveranse

Leveransen vil bestå av:

- **Markdown-dokumenter** for rammeverk, IA, tilstandsinventar, terminologi og retningslinjer
- **Gråtone wireframe-filer** (Figma eller tilsvarende, eller annoterte SVG/HTML dersom Figma ikke ønskes)
- **Design token-spesifikasjon** som strukturert JSON eller tilsvarende format
- **Oppgavespesifikasjoner** i det definerte markdown-formatet, klar for implementasjonsplanlegging

Alle dokumenter leveres i klarspråk og skal kunne brukes direkte av utviklerne uten at de trenger å tolke designet.

---

## Spørsmål jeg ber om svar på

Før jeg starter:

1. Skal wireframes leveres i Figma, eller foretrekker dere et annet format?
2. Er norsk eller engelsk foretrukket produktspråk i designet?
3. Har dere noen eksisterende farger, typografi eller visuell identitet vi bør ta hensyn til?
4. Hva er den aller viktigste brukerfrustrasjon med nåværende UI – om dere skulle nevne én ting?
5. Er mørk modus et krav nå, eller kan det utsettes?

---

*Dette forslaget er mitt utgangspunkt. Jeg er åpen for justeringer av scope, sekvens og leveranseformat basert på deres tilbakemelding.*
